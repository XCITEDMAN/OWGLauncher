# OWG Launcher

DayZ launcher for the Older Wiser Gamers servers.

## Day-to-day: editing `servers.json` on GitHub

The launcher reads `https://raw.githubusercontent.com/XCITEDMAN/OWGLauncher/main/servers.json`
at startup and again every 10 minutes. Edit the file on GitHub (pencil icon → Commit changes).
Changes can take up to ~5 minutes to show because GitHub caches the file.

If the file ever has a typo, launchers keep using the last good copy, so nothing breaks —
but your change won't show up until it's fixed. Paste the file into https://jsonlint.com to check it.

### Add an announcement
Add an entry to `"announcements"`:
```json
{ "id": "wipe-dec", "date": "2026-12-01", "title": "Wipe tonight",
  "body": "All servers wipe at 6 PM Central.", "pinned": true, "expires": "2026-12-02" }
```
`pinned` keeps it on top. `expires` (YYYY-MM-DD) hides it automatically after that date; use `null` for never.

### Server headings
`"groups"` lists the headings in the order they appear, and each server picks one with `"group"`:
```json
"groups": [ { "id": "hived", "title": "Hived Servers" }, { "id": "standalone", "title": "Standalone Servers" } ]
```
A server with no `"group"` goes under the first heading. `"order"` sorts servers within a heading.
Rename a heading by changing its `title`; add a heading by adding another entry.

### Add a server
Copy a server block, change `id` (unique, no spaces), `name`, `gamePort`, `queryPort` and `order`.
Optional fields:
- `"host": "something.duckdns.org"` — only if this server is on a different address than `defaultHost`
- `"description": "PvE, 1PP"` — short text shown on the card
- `"enabled": false` — hides the server without deleting it
- `"image": "images/deadfall.png"` — artwork shown faded behind the Rejoin button when this is the
  player's last server. Upload the picture to an `images` folder in the repo (PNG/JPG/WebP, under 5 MB;
  a transparent PNG about 800×600 looks best). A full `https://` link also works.
- `"imageOpacity": 0.3` — optional, how strong the artwork shows (0.05 faint … 1 solid; default 0.22)

### Change the IP
Change `defaultHost` (or a server's `host`). Once DuckDNS is set up, put the DuckDNS name there and
you never have to touch it again.

### Mods
Nothing to do: the launcher reads each server's mod list straight from the running server.
Optional fallback (used when a server is offline and the launcher has never seen its list):
```json
"mods": [ { "name": "CF", "workshopId": "1559212036" } ]
```
Add `"modsOverride": true` to always use that list instead of what the server reports.

### Publishing a launcher update (auto-update)
1. On GitHub: Releases → Draft a new release.
2. Tag: `v` + the version (e.g. `v1.0.5`). Title: anything.
3. Attach the installer **exe** (not a zip), named exactly `OWG-Launcher-Setup-<version>.exe`.
4. Optional: write a short note in the description — players see the first lines in the update banner.
5. Publish.

Launchers check GitHub at startup and every 15 minutes (never while DayZ is starting or running —
they catch up right after the game closes). They download the update in the background,
verify it, then show **Restart & update**. If the player just closes the launcher, the update
installs quietly at that point. Updates never install while DayZ is running or a join is in progress.

## Join screen (intro after Play / Rejoin)
A full-window intro plays for `maxSeconds` (default 120) after a player clicks Play or Rejoin:
pictures cross-fade (and videos play, muted) with the message along the bottom. Set the default at the
top of servers.json, and optionally give any server its own `"joinScreen"` to override it:
```json
"joinScreen": {
  "message": "You are joining \"{server}\". Prepare to survive or die trying.",
  "media": ["join/loot.jpg", "join/convoy.mp4"],
  "slideSeconds": 6,
  "maxSeconds": 120
}
```
- `{server}` becomes the server's name (shown in gold).
- `media`: files in the repo (or https links). Pictures: JPG/PNG/WebP up to 8 MB. Videos: MP4 or WebM up
  to 60 MB (GitHub's website upload limit is 25 MB per file). Launchers download them in the background
  ahead of time. Videos play muted, each one to its end (max 45 s) before the next item.
- Give each server its own list so it shows only its media: inside the server's entry,
  `"joinScreen": { "media": ["join/deadfall-1.jpg", "join/deadfall-2.mp4"] }`.
  A server's own list always wins; the top-level list (if any) is only used by servers without one.
- With no media at all, a server shows just its own artwork (or the OWG logo if it has none).
- `"enabled": false` turns the intro off (globally or for one server).

## Discord announcements
A GitHub job (`.github/workflows/discord-announcements.yml` + `scripts/discord-announcements.mjs`)
reads the latest posts in the Discord announcements channel every ~5 minutes and saves them to
`announcements.json`. Launchers check that file every 2 minutes, highlight new posts, and play the
"Attention!" alert (players can turn it off with the Sounds switch; it stays quiet while DayZ is running).

Settings (repo → Settings → Secrets and variables → Actions):
- Secret `DISCORD_BOT_TOKEN` — the bot's token
- Variable `DISCORD_CHANNEL_ID` — the channel's ID
- Variable `DISCORD_MAX_MESSAGES` — optional, how many recent posts to show (default 10)

To push an announcement out immediately: Actions tab → Discord announcements → Run workflow.
Manual announcements in servers.json still work and show alongside the Discord posts.

### Faster announcements (Cloudflare Worker)
GitHub's scheduler often skips runs, so the recommended source is a free Cloudflare Worker
(`worker/worker.js`) that reads the Discord channel whenever a launcher asks (cached 45 s).
Set `"announcementsUrl": "https://<your-worker>.workers.dev/"` at the top of servers.json.
Launchers then check every minute; the GitHub copy is only used if the Worker can't be reached.

## Where the launcher keeps things on a player's PC
`%APPDATA%\OWG Launcher\` — `settings.json` (player name, last server, auto-join),
`config-cache.json` (last good server list), `mods-cache.json` (last known mod lists).
Mod shortcuts it creates: `<DayZ folder>\!OWG\@<workshop id>` (links to Steam's Workshop folders, no copies).

## Building (for a developer)
Electron app. `npm install`, then `npx electron-builder --win dir --x64` and
`makensis -DVERSION=x.y.z build/installer.nsi` to produce `dist/OWG-Launcher-Setup-x.y.z.exe`.
Bump `version` in `package.json` for each release.

Key files: `src/main.js` (logic), `src/a2s.js` (server query + mod list decoding),
`src/steam-local.js` (reads Steam's files for download status), `src/steam-worker.js`
(Steam API: subscribe/download mods; runs only while preparing a launch), `src/ui/` (interface).
