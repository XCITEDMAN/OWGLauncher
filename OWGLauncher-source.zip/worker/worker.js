// OWG announcements — Cloudflare Worker.
// Reads the latest posts from the OWG Discord announcements channel when a launcher asks,
// and returns them as JSON. Results are cached for 45 seconds so Discord is never hammered.
//
// Settings (Worker → Settings → Variables and Secrets):
//   DISCORD_BOT_TOKEN   (Secret)  the bot's token
//   DISCORD_CHANNEL_ID  (Text)    the announcements channel ID
//   MAX_MESSAGES        (Text)    optional, how many posts to return (default 6)

const API = 'https://discord.com/api/v10';
const CACHE_SECONDS = 45;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (request.method !== 'GET') return new Response('Method not allowed', { status: 405 });
    if (url.pathname !== '/' && url.pathname !== '/announcements.json') return new Response('Not found', { status: 404 });

    const cache = caches.default;
    const key = new Request(`${url.origin}/announcements.json`);
    const hit = await cache.match(key);
    if (hit) return hit;

    let body;
    try {
      body = await readChannel(env);
    } catch (e) {
      return json({ error: String(e.message || e) }, 502, 0);
    }
    const res = json(body, 200, CACHE_SECONDS);
    ctx.waitUntil(cache.put(key, res.clone()));
    return res;
  },
};

function json(obj, status, maxAge) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': `public, max-age=${maxAge}` },
  });
}

async function api(env, path) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(API + path, { headers: { Authorization: `Bot ${env.DISCORD_BOT_TOKEN}`, 'User-Agent': 'OWG-Launcher-Announcements (worker, 1.0)' } });
    if (res.status === 429) {
      const j = await res.json().catch(() => ({}));
      await new Promise((r) => setTimeout(r, Math.ceil((j.retry_after || 1) * 1000)));
      continue;
    }
    if (res.status === 401) throw new Error('Discord rejected the bot token (check DISCORD_BOT_TOKEN).');
    if (res.status === 403) throw new Error('The bot cannot read this channel (needs View Channel + Read Message History).');
    if (res.status === 404) throw new Error('Channel not found (check DISCORD_CHANNEL_ID).');
    if (!res.ok) throw new Error(`Discord API error ${res.status}`);
    return res.json();
  }
  throw new Error('Discord kept rate-limiting the request.');
}

async function readChannel(env) {
  const CHANNEL = String(env.DISCORD_CHANNEL_ID || '').trim();
  if (!env.DISCORD_BOT_TOKEN) throw new Error('DISCORD_BOT_TOKEN secret is missing.');
  if (!/^\d{15,22}$/.test(CHANNEL)) throw new Error('DISCORD_CHANNEL_ID is missing or not a channel ID.');
  const MAX = Math.min(Math.max(parseInt(env.MAX_MESSAGES || '6', 10) || 6, 1), 50);

  const channel = await api(env, `/channels/${CHANNEL}`);
  const guildId = channel.guild_id;
  const [messages, roles, channels] = await Promise.all([
    api(env, `/channels/${CHANNEL}/messages?limit=${MAX}`),
    guildId ? api(env, `/guilds/${guildId}/roles`).catch(() => []) : [],
    guildId ? api(env, `/guilds/${guildId}/channels`).catch(() => []) : [],
  ]);
  const roleName = new Map((roles || []).map((r) => [r.id, r.name]));
  const chanName = new Map((channels || []).map((c) => [c.id, c.name]));
  const displayName = (u) => (u && ((u.member && u.member.nick) || u.global_name || u.username)) || 'Someone';

  const clean = (text, m) => {
    if (!text) return '';
    const users = new Map((m.mentions || []).map((u) => [u.id, displayName(u)]));
    return text
      .replace(/<@!?(\d+)>/g, (_, id) => `@${users.get(id) || 'member'}`)
      .replace(/<@&(\d+)>/g, (_, id) => `@${roleName.get(id) || 'role'}`)
      .replace(/<#(\d+)>/g, (_, id) => `#${chanName.get(id) || 'channel'}`)
      .replace(/<a?:(\w+):\d+>/g, ':$1:')
      .replace(/<t:(\d+)(?::([tTdDfFR]))?>/g, (_, ts, style) => `{{ts:${ts}:${style || 'f'}}}`)
      .replace(/<(https?:\/\/[^>\s]+)>/g, '$1')
      .trim();
  };

  const items = messages
    .filter((m) => m.type === 0 || m.type === 19)
    .map((m) => {
      const parts = [clean(m.content, m)];
      for (const e of m.embeds || []) {
        if (e.type && !['rich', 'article', 'link'].includes(e.type)) continue;
        const t = [e.title ? `**${clean(e.title, m)}**` : '', clean(e.description, m)].filter(Boolean).join('\n');
        if (t && !parts[0].includes(t)) parts.push(t);
      }
      return {
        id: m.id,
        timestamp: m.timestamp,
        edited: m.edited_timestamp || null,
        author: displayName({ ...m.author, member: m.member }),
        text: parts.filter(Boolean).join('\n\n').slice(0, 4000),
        attachments: (m.attachments || []).map((a) => a.filename).slice(0, 10),
        url: guildId ? `https://discord.com/channels/${guildId}/${CHANNEL}/${m.id}` : null,
      };
    })
    .filter((i) => i.text || i.attachments.length);

  const newest = items.reduce((t, i) => Math.max(t, Date.parse(i.edited || i.timestamp) || 0), 0);
  return { schemaVersion: 1, source: 'discord', channel: channel.name, updated: newest ? new Date(newest).toISOString() : null, items };
}
