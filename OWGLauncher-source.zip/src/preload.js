'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('owg', {
  getState: () => ipcRenderer.invoke('get-state'),
  onState: (fn) => ipcRenderer.on('state', (_e, s) => fn(s)),
  play: (id, opts) => ipcRenderer.invoke('play', id, opts),
  setPassword: (id, pw, remember) => ipcRenderer.invoke('set-password', id, pw, remember),
  cancel: () => ipcRenderer.invoke('cancel'),
  dismiss: () => ipcRenderer.invoke('dismiss'),
  refresh: () => ipcRenderer.invoke('refresh'),
  installUpdate: () => ipcRenderer.invoke('install-update'),
  markRead: (id) => ipcRenderer.invoke('mark-read', id),
  onAlert: (fn) => ipcRenderer.on('alert', () => fn()),
  saveSettings: (s) => ipcRenderer.invoke('save-settings', s),
  openUrl: (u) => ipcRenderer.invoke('open-url', u),
  win: (a) => ipcRenderer.invoke('win', a),
});
