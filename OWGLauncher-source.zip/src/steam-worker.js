// Short-lived helper process that talks to the Steam client.
// It runs only while mods are being subscribed/downloaded and is closed
// before DayZ starts, so it never gets in the way of the game.
'use strict';

let client = null;
const DAYZ = 221100;

// Steam Workshop item state flags (ISteamUGC::EItemState)
const S = { SUBSCRIBED: 1, INSTALLED: 4, NEEDS_UPDATE: 8, DOWNLOADING: 16, PENDING: 32 };

function reply(id, data) { process.send && process.send({ id, ...data }); }

function itemInfo(idStr) {
  const id = BigInt(idStr);
  const st = client.workshop.state(id);
  const info = {
    id: idStr,
    subscribed: Boolean(st & S.SUBSCRIBED),
    installed: Boolean(st & S.INSTALLED),
    needsUpdate: Boolean(st & S.NEEDS_UPDATE),
    downloading: Boolean(st & S.DOWNLOADING),
    pending: Boolean(st & S.PENDING),
    current: 0,
    total: 0,
    folder: null,
  };
  const dl = client.workshop.downloadInfo(id);
  if (dl) { info.current = Number(dl.current); info.total = Number(dl.total); }
  const inst = client.workshop.installInfo(id);
  if (inst) info.folder = inst.folder;
  info.ready = info.installed && !info.needsUpdate && !info.downloading && !info.pending && Boolean(info.folder);
  return info;
}

process.on('message', async (msg) => {
  try {
    switch (msg.cmd) {
      case 'init': {
        try {
          client = require('steamworks.js').init(DAYZ);
        } catch (e) {
          return reply(msg.id, { ok: false, error: 'steam-not-running', detail: String(e && e.message) });
        }
        let name = null;
        try { name = client.localplayer.getName(); } catch {}
        let dayzDir = null;
        try { dayzDir = client.apps.appInstallDir(DAYZ); } catch {}
        return reply(msg.id, { ok: true, name, dayzDir });
      }
      case 'dlc': {
        const out = {};
        for (const appId of msg.appIds) {
          try { out[appId] = client.apps.isDlcInstalled(Number(appId)) || client.apps.isSubscribedApp(Number(appId)); }
          catch { out[appId] = null; }
        }
        return reply(msg.id, { ok: true, dlc: out });
      }
      case 'status': {
        const items = {};
        for (const id of msg.ids) items[id] = itemInfo(id);
        return reply(msg.id, { ok: true, items });
      }
      case 'ensure': {
        // Subscribe to anything missing and push downloads to the front of the queue.
        for (const idStr of msg.ids) {
          const id = BigInt(idStr);
          const info = itemInfo(idStr);
          if (!info.subscribed) {
            try { await client.workshop.subscribe(id); } catch {}
          }
          if (!info.installed || info.needsUpdate || info.pending || msg.force) {
            try { client.workshop.download(id, true); } catch {}
          }
        }
        return reply(msg.id, { ok: true });
      }
      case 'quit':
        reply(msg.id, { ok: true });
        setTimeout(() => process.exit(0), 50);
        return;
      default:
        return reply(msg.id, { ok: false, error: 'unknown-command' });
    }
  } catch (e) {
    reply(msg.id, { ok: false, error: String(e && e.message) });
  }
});

process.on('disconnect', () => process.exit(0));
