// Steam server query (A2S) for DayZ: server info + mod list.
// Mod list decoding follows the Arma 3 / DayZ ServerBrowserProtocol
// (binary payload chunked across A2S_RULES entries).
'use strict';
const dgram = require('dgram');

const HDR = Buffer.from([0xff, 0xff, 0xff, 0xff]);

function request(host, port, payload, timeoutMs = 2500) {
  // Sends one request, handles the challenge round-trip and split packets.
  return new Promise((resolve, reject) => {
    const sock = dgram.createSocket('udp4');
    let done = false;
    const parts = new Map();
    let total = null;
    let triedChallenge = false;

    const finish = (err, buf) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { sock.close(); } catch {}
      err ? reject(err) : resolve(buf);
    };
    const timer = setTimeout(() => finish(new Error('timeout')), timeoutMs);

    const send = (buf) => sock.send(buf, port, host, (e) => e && finish(e));

    const handleSimple = (body) => {
      // body starts after FF FF FF FF
      if (body[0] === 0x41 && !triedChallenge) { // S2C_CHALLENGE
        triedChallenge = true;
        const challenge = body.subarray(1, 5);
        send(payload(challenge));
        return;
      }
      finish(null, body);
    };

    sock.on('message', (msg) => {
      const type = msg.readInt32LE(0);
      if (type === -1) return handleSimple(msg.subarray(4));
      if (type === -2) {
        // Source multi-packet: id(4) total(1) number(1) [size(2)] payload
        const number = msg[9];
        total = msg[8];
        let offset = 10;
        // Some engines include a 2-byte size field. Packet 0's payload
        // always begins with FF FF FF FF, which lets us detect it.
        if (number === 0) {
          offset = msg.readInt32LE(12) === -1 ? 12 : 10;
          parts.set('offset', offset);
        } else if (parts.has('offset')) {
          offset = parts.get('offset');
        } else {
          offset = 12; // DayZ includes the size field
        }
        parts.set(number, msg.subarray(offset));
        const got = [...parts.keys()].filter((k) => k !== 'offset').length;
        if (got === total) {
          const bufs = [];
          for (let i = 0; i < total; i++) bufs.push(parts.get(i));
          const whole = Buffer.concat(bufs);
          handleSimple(whole.subarray(4));
        }
      }
    });
    sock.on('error', (e) => finish(e));
    send(payload(null));
  });
}

class Reader {
  constructor(buf) { this.b = buf; this.o = 0; }
  byte() { return this.b[this.o++]; }
  short() { const v = this.b.readInt16LE(this.o); this.o += 2; return v; }
  ushort() { const v = this.b.readUInt16LE(this.o); this.o += 2; return v; }
  ulong() { const v = this.b.readUInt32LE(this.o); this.o += 4; return v; }
  long() { const v = this.b.readInt32LE(this.o); this.o += 4; return v; }
  u64() { const v = this.b.readBigUInt64LE(this.o); this.o += 8; return v; }
  float() { const v = this.b.readFloatLE(this.o); this.o += 4; return v; }
  cstr() {
    const end = this.b.indexOf(0, this.o);
    const e = end < 0 ? this.b.length : end;
    const s = this.b.subarray(this.o, e);
    this.o = e + 1;
    return s;
  }
  bytes(n) { const s = this.b.subarray(this.o, this.o + n); this.o += n; return s; }
  left() { return this.b.length - this.o; }
}

async function queryInfo(host, port) {
  const started = Date.now();
  const body = await request(host, port, (ch) =>
    Buffer.concat([HDR, Buffer.from('TSource Engine Query\0', 'latin1'), ch || Buffer.alloc(0)]));
  const ping = Date.now() - started;
  if (body[0] !== 0x49) throw new Error('unexpected info reply');
  const r = new Reader(body.subarray(1));
  r.byte(); // protocol
  const info = {
    name: r.cstr().toString('utf8'),
    map: r.cstr().toString('utf8'),
    folder: r.cstr().toString('utf8'),
    game: r.cstr().toString('utf8'),
    appId: r.short(),
    players: r.byte(),
    maxPlayers: r.byte(),
    bots: r.byte(),
    serverType: String.fromCharCode(r.byte()),
    environment: String.fromCharCode(r.byte()),
    passworded: r.byte() === 1,
    vac: r.byte() === 1,
    version: r.cstr().toString('utf8'),
    keywords: [],
    ping,
  };
  if (r.left() > 0) {
    const edf = r.byte();
    if (edf & 0x80) r.short(); // game port
    if (edf & 0x10) r.u64(); // steam id
    if (edf & 0x40) { r.short(); r.cstr(); } // spectator
    if (edf & 0x20) info.keywords = r.cstr().toString('utf8').split(',');
  }
  // DayZ keywords carry extra state, e.g. "battleye,no3rd,etm2.000000,lqs0,..,10:45"
  for (const k of info.keywords) {
    if (/^\d{1,2}:\d{2}$/.test(k)) info.time = k;
    if (k === 'battleye') info.battleye = true;
    if (k === 'no3rd') info.firstPersonOnly = true;
    if (k === 'privHive') info.privateHive = true;
    if (k === 'shard') info.shard = true;
  }
  return info;
}

function translateEscapes(buf) {
  const out = [];
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] === 0x01 && i + 1 < buf.length) {
      const n = buf[i + 1];
      if (n === 0x01) { out.push(0x01); i++; continue; }
      if (n === 0x02) { out.push(0x00); i++; continue; }
      if (n === 0x03) { out.push(0xff); i++; continue; }
    }
    out.push(buf[i]);
  }
  return Buffer.from(out);
}

async function queryMods(host, port) {
  const body = await request(host, port, (ch) =>
    Buffer.concat([HDR, Buffer.from([0x56]), ch || Buffer.from([0xff, 0xff, 0xff, 0xff])]), 4000);
  if (body[0] !== 0x45) throw new Error('unexpected rules reply');
  const r = new Reader(body.subarray(1));
  const count = r.ushort();
  const chunks = [];
  for (let i = 0; i < count && r.left() > 0; i++) {
    const key = r.cstr();
    const val = r.cstr();
    if (key.length === 2) chunks.push({ idx: key[0], total: key[1], val });
  }
  chunks.sort((a, b) => a.idx - b.idx);
  const data = translateEscapes(Buffer.concat(chunks.map((c) => c.val)));
  const d = new Reader(data);
  const version = d.byte();
  d.byte(); // overflow flags
  const dlcFlags = d.ushort();
  if (version !== 2) d.ushort(); // difficulty (protocol 3)
  let bits = 0;
  for (let f = dlcFlags; f; f >>= 1) bits += f & 1;
  for (let i = 0; i < bits; i++) d.ulong();
  const nMods = d.byte();
  const mods = [];
  for (let i = 0; i < nMods; i++) {
    d.ulong(); // hash
    const lenByte = d.byte();
    const isDlc = Boolean((lenByte >> 4) & 1);
    const len = lenByte & 0x0f;
    const idBytes = d.bytes(len);
    let id = 0n;
    for (let j = idBytes.length - 1; j >= 0; j--) id = (id << 8n) | BigInt(idBytes[j]);
    const nameLen = d.byte();
    const name = d.bytes(nameLen).toString('utf8');
    mods.push({ id: id.toString(), name, dlc: isDlc });
  }
  return mods;
}

module.exports = { queryInfo, queryMods };
