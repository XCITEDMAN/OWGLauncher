// Generated from OWG-Launcher-Help.txt
window.OWG_HELP = [
 {
  "n": "1",
  "title": "Getting started",
  "body": "Before you play, you need:\n  • Steam installed, running, and signed in\n  • DayZ installed through Steam\n  • Any DayZ DLC a server requires (the launcher will tell you)\n\nFirst time:\n  1. Start Steam and sign in.\n  2. Open OWG Launcher from your desktop or Start menu.\n  3. Type your player name at the bottom of the window.\n  4. Pick a server with a green light and click PLAY.\n\nThe launcher downloads any mods you need, starts DayZ, and\nconnects you to the server. There's nothing else to set up."
 },
 {
  "n": "2",
  "title": "The main screen",
  "body": "  • Top banner area — important messages, such as \"Steam is\n    updating mods\" or \"Launcher update ready.\"\n  • Rejoin card — the big card at the top shows the last server\n    you played. Click REJOIN to go straight back in.\n  • Servers — every OWG server, with its status, players\n    online, map, in-game time, and mod status.\n  • Announcements (right side) — news from the OWG Discord.\n  • Bottom bar — your player name and settings switches.\n  • Refresh — checks all servers right now instead of waiting."
 },
 {
  "n": "3",
  "title": "Joining a server",
  "body": "  1. Click PLAY on a server (or REJOIN on the top card).\n  2. The launcher checks your mods and downloads any that are\n     missing or out of date. A window shows the progress.\n  3. When everything is ready, DayZ starts and connects you\n     to the server automatically.\n\n  While you wait, a full-screen intro plays for about two minutes.\n  Click the ✕ in its corner (or press Esc) to close it early —\n  joining carries on either way.\n\n  • You can click Cancel at any time while mods download.\n  • The launcher remembers the last server you joined and\n    offers it first next time.\n  • PLAY is greyed out when a server is offline.\n  • While DayZ is starting or open, the buttons show STARTING…\n    or IN GAME. They unlock a few seconds after you close DayZ."
 },
 {
  "n": "4",
  "title": "Server status lights",
  "body": "  • Green — the server is up and you can join.\n  • Red — the server is offline or restarting. Try again in a\n    few minutes.\n  • Grey, blinking — the launcher is still checking.\n\nStatus refreshes every 30 seconds on its own."
 },
 {
  "n": "5",
  "title": "Mods",
  "body": "You don't need to manage mods yourself. The launcher reads each\nserver's mod list and has Steam download whatever you're missing.\n\nWhat the mod messages mean:\n  • \"✓ 18 mods ready\" — you're all set.\n  • \"3 of 18 mods to download — handled when you hit Play\" —\n    they'll download when you click PLAY.\n  • \"⬇ Steam updating 2 mods\" — Steam is downloading updates\n    right now. Wait for it to finish before joining, or you may\n    be kicked for a mod mismatch.\n\nIf a download seems stuck, the launcher shows a tip. Usually:\n  • Open Steam > Downloads and make sure downloads aren't paused.\n  • Steam may be set to only download when no game is running —\n    close any running game.\n\nMods are downloaded through your Steam account, the same as\nsubscribing to them on the Steam Workshop."
 },
 {
  "n": "6",
  "title": "Password-protected servers",
  "body": "Servers that need a password show a 🔒 Password tag.\n\n  • Click PLAY and the launcher asks for the password.\n  • Tick \"Remember on this PC\" to skip this next time.\n  • To change or clear a saved password, click the 🔑 button\n    next to PLAY.\n\nAsk an OWG admin for the password. If DayZ says the password is\nwrong, use the 🔑 button to enter it again."
 },
 {
  "n": "7",
  "title": "Your player name",
  "body": "Type the name you want to use in the \"Player name\" box at the\nbottom of the window. It's saved automatically and used every time\nyou join. If you leave it blank, the launcher uses your Steam name."
 },
 {
  "n": "8",
  "title": "Settings (switches at the bottom)",
  "body": "  • Auto-join when mods finish — ON: after mods download, you're\n    connected automatically. OFF: the launcher waits for you to\n    click PLAY NOW.\n  • Sounds — plays the \"Attention!\" alert when a new\n    announcement arrives. Alerts never play while DayZ is running.\n  • Minimize when DayZ starts — tucks the launcher away once the\n    game opens."
 },
 {
  "n": "9",
  "title": "Announcements",
  "body": "Announcements come straight from the OWG Discord announcements\nchannel and appear on the right side of the launcher.\n\n  • New posts glow gold and have a NEW tag.\n  • Click a new post to mark it as read, or use \"Mark all read.\"\n  • \"View in Discord\" opens the post in Discord.\n  • If the launcher is minimized, its taskbar icon flashes and\n    Windows shows a notification.\n\nNew posts usually appear within 5–20 minutes of being posted."
 },
 {
  "n": "10",
  "title": "Launcher updates",
  "body": "The launcher updates itself.\n\n  1. Every 15 minutes the launcher checks for a new version and\n     downloads it in the background. While DayZ is running it\n     waits, and downloads once you're out of the game.\n  2. A banner says \"Launcher update ready.\" Click\n     RESTART & UPDATE — the launcher closes and reopens in a few\n     seconds on the new version.\n  3. If you'd rather not restart now, the update installs\n     automatically the next time you close the launcher.\n\nUpdates never install while DayZ is running. Your version number\nis shown at the bottom-right corner."
 },
 {
  "n": "11",
  "title": "Troubleshooting",
  "body": "\"Steam isn't running\"\n  Start Steam and sign in, then try again.\n\n\"DayZ not found\"\n  Install DayZ through Steam on this PC, then reopen the launcher.\n\nServer shows a red light\n  The server is offline or restarting. Wait a few minutes. If it\n  stays red for a long time, let an OWG admin know.\n\nKicked: \"BattlEye ... Game restart required\"\n  BattlEye (DayZ's anti-cheat) didn't start. Make sure your\n  antivirus isn't blocking BattlEye. If it keeps happening, try\n  joining from DayZ's own server browser — if that also fails,\n  the problem is BattlEye on your PC, not the launcher.\n\nKicked for mods / \"mismatch\" / \"signature\"\n  A mod is outdated. Wait until no \"Steam updating mods\" banner\n  is showing, then join again.\n\n\"requires DayZ DLC you don't own\"\n  That server uses a paid DayZ DLC. Click \"Open in Steam Store\"\n  to get it.\n\nWindows says \"Windows protected your PC\" when installing\n  Click \"More info\", then \"Run anyway.\" This only happens on the\n  first install.\n\nAnnouncements aren't showing\n  Click Refresh. New Discord posts can take up to 20 minutes."
 },
 {
  "n": "12",
  "title": "Getting more help",
  "body": "Still stuck? Post in the OWG Discord and include:\n  • which server you were joining\n  • what the launcher or DayZ said (a screenshot helps)\n  • your launcher version (bottom-right corner)"
 }
];
