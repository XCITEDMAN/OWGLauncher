'use strict';
/* global owg */
let S = null;
let nameTimer = null;
let pwPrompt = null; // { serverId, mode: 'join' | 'edit' }

const $ = (id) => document.getElementById(id);
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
const mb = (n) => `${Math.round((n || 0) / 1048576)} MB`;
const pct = (c, t) => (t ? Math.min(100, Math.round((c / t) * 100)) : null);

function mapName(m) {
  if (!m) return '';
  return m.charAt(0).toUpperCase() + m.slice(1);
}

function lightClass(s) {
  if (!s.status) return 'light checking';
  return s.status.up ? 'light up' : 'light down';
}

function modLine(s) {
  const sum = s.modSummary;
  const span = el('span');
  if (!s.mods.length && sum.unknown) { span.className = 'dim'; span.textContent = s.status && s.status.up ? 'Reading mod list…' : 'Mod list unavailable'; return span; }
  if (!sum.total) { span.className = 'ok'; span.textContent = 'No mods needed'; return span; }
  if (sum.updating.length) {
    const cur = sum.updating.reduce((a, u) => a + (u.current || 0), 0);
    const tot = sum.updating.reduce((a, u) => a + (u.total || 0), 0);
    const p = pct(cur, tot);
    span.className = 'warn';
    span.textContent = `⬇ Steam updating ${sum.updating.length} mod${sum.updating.length > 1 ? 's' : ''}${p !== null && cur ? ` · ${p}%` : ''}`;
    return span;
  }
  if (sum.missing) { span.className = 'warn'; span.textContent = `${sum.missing} of ${sum.total} mods to download — handled when you hit Play`; return span; }
  if (sum.ready === sum.total) { span.className = 'ok'; span.textContent = `✓ ${sum.total} mods ready`; return span; }
  span.className = 'dim'; span.textContent = `${sum.total} mod${sum.total === 1 ? '' : 's'}`;
  return span;
}

function startPlay(s) {
  const info = s.status && s.status.info;
  if (info && info.passworded && !s.hasPassword) return openPw(s.id, 'join');
  owg.play(s.id);
}

function openPw(serverId, mode) {
  const s = S.serverList.find((x) => x.id === serverId);
  if (!s) return;
  pwPrompt = { serverId, mode };
  $('pwTitle').textContent = mode === 'join' ? `${s.name} needs a password` : `Password for ${s.name}`;
  $('pwMsg').textContent = mode === 'join'
    ? 'This server is password protected. Ask the server admin for the password.'
    : (s.hasPassword ? 'A password is saved for this server. Enter a new one to replace it.' : 'Save the password so Play joins straight in.');
  $('pwInput').value = '';
  $('pwInput').type = 'password';
  $('pwShow').checked = false;
  $('pwRemember').checked = true;
  $('pwOk').textContent = mode === 'join' ? 'JOIN' : 'SAVE';
  $('pwForget').classList.toggle('hidden', !s.hasPassword);
  $('pwOverlay').classList.remove('hidden');
  setTimeout(() => $('pwInput').focus(), 30);
}
function closePw() { pwPrompt = null; $('pwOverlay').classList.add('hidden'); }

function playDisabled(s) {
  return Boolean(S.play && S.play.active) || Boolean(S.gameRunning) || Boolean(S.launching) || !s.status || !s.status.up;
}
// Button text while DayZ is starting or open.
function playLabel(normal) {
  if (S.launching) return 'STARTING…';
  if (S.gameRunning) return 'IN GAME';
  return normal;
}

function renderAlerts() {
  const box = $('alerts'); box.replaceChildren();
  const add = (kind, icon, title, text, extra) => {
    const a = el('div', `alert ${kind}`);
    a.append(el('div', 'a-icon', icon));
    const b = el('div', 'a-body');
    b.append(el('div', 'a-title', title));
    if (text) b.append(el('div', 'a-text', text));
    if (extra) b.append(extra);
    a.append(b);
    box.append(a);
    return a;
  };

  const u = S.update;
  if (u && u.status === 'downloading') {
    const bar = el('div', 'mini-bar'); const f = el('div'); f.style.width = `${u.percent || 0}%`; bar.append(f);
    add('info', '★', `Downloading launcher update ${u.version}… ${u.percent || 0}%`, 'You can keep using the launcher while it downloads.', bar);
  } else if (u && u.status === 'ready') {
    const a = add('info', '★', `Launcher update ${u.version} is ready`, u.notes || 'Restart the launcher to finish updating. It will also update the next time you close it.');
    const btn = el('button', 'btn-play small', 'RESTART & UPDATE');
    btn.disabled = Boolean(S.play && S.play.active);
    btn.onclick = () => owg.installUpdate();
    a.append(btn);
  } else if (u && u.status === 'installing') {
    add('info', '★', `Installing update ${u.version}…`, 'The launcher will reopen in a few seconds.');
  } else if (S.updateAvailable) {
    const a = add('info', '★', `Launcher update available — version ${S.updateAvailable.version}`, S.updateAvailable.notes || 'Download the new version to get the latest fixes.');
    const btn = el('button', 'btn-play small', 'Download');
    btn.onclick = () => owg.openUrl(S.updateAvailable.url);
    a.append(btn);
  }

  // Steam downloading mods for any server
  const updating = new Map();
  for (const s of S.serverList) for (const u of s.modSummary.updating) updating.set(u.id, u);
  if (updating.size) {
    const list = [...updating.values()];
    const cur = list.reduce((x, u) => x + (u.current || 0), 0);
    const tot = list.reduce((x, u) => x + (u.total || 0), 0);
    const p = pct(cur, tot);
    const names = list.slice(0, 3).map((u) => u.name).join(', ') + (list.length > 3 ? ` +${list.length - 3} more` : '');
    let extra = null;
    if (p !== null && cur) { extra = el('div', 'mini-bar'); const f = el('div'); f.style.width = `${p}%`; extra.append(f); }
    add('warn', '⬇', `Steam is updating ${list.length} mod${list.length > 1 ? 's' : ''} — wait before joining`,
      `${names}${p !== null && cur ? ` · ${mb(cur)} of ${mb(tot)}` : list.some((u) => !u.downloading) ? ' · waiting in Steam’s download queue' : ''}`, extra);
  }

  if (S.steamRunning === false) add('err', '!', 'Steam isn’t running', 'Start Steam and sign in so the launcher can check and download mods.');
  if (S.dayzFound === false && S.steamRunning) add('err', '!', 'DayZ not found', 'Install DayZ through Steam on this PC, then reopen the launcher.');
  if (S.launching) add('info', '▶', 'DayZ is starting…', 'This can take a minute or two. Play buttons unlock once DayZ closes.');
  else if (S.gameRunning) add('info', '▶', 'DayZ is running', 'Play buttons unlock when you close DayZ. Have fun out there.');
  if (S.configSource && S.configSource !== 'live') add('warn', '!', 'Couldn’t reach the OWG server list', 'Showing the last list this launcher saved. It will try again in a few minutes.');
}

function renderHero() {
  const box = $('hero'); box.replaceChildren();
  const hero = el('div', 'hero');
  const art = el('div', 'hero-art');
  const artServer = S.serverList.find((x) => x.id === S.settings.lastServerId);
  if (artServer && artServer.imageUrl) {
    art.classList.add('custom');
    art.style.backgroundImage = `url("${artServer.imageUrl}")`;
    // Wide pictures (landscapes) fill the whole card; tall or square ones sit behind the button.
    const probe = new Image();
    probe.onload = () => { if (probe.naturalWidth / probe.naturalHeight > 1.6) art.classList.add('banner'); };
    probe.src = artServer.imageUrl;
    if (probe.complete && probe.naturalWidth / probe.naturalHeight > 1.6) art.classList.add('banner');
    if (artServer.imageOpacity) art.style.opacity = String(artServer.imageOpacity);
  }
  hero.append(art);
  const txt = el('div', 'h-text');
  const last = S.serverList.find((s) => s.id === S.settings.lastServerId);
  const name = S.settings.playerName;
  if (last) {
    txt.append(el('div', 'h-kicker', name ? `Welcome back, ${name} — jump back in` : 'Jump back in'));
    txt.append(el('div', 'h-name', last.name));
    const meta = el('div', 'h-meta');
    const l = el('span', lightClass(last)); meta.append(l);
    if (last.status && last.status.up) {
      const i = last.status.info;
      meta.append(el('span', null, `${i.players}/${i.maxPlayers} online`));
      if (i.map) meta.append(el('span', null, mapName(i.map)));
      if (i.time) meta.append(el('span', null, `In-game ${i.time}`));
    } else meta.append(el('span', null, last.status ? 'Server is down' : 'Checking…'));
    meta.append(modLine(last));
    txt.append(meta);
    hero.append(txt);
    const b = el('button', 'btn-play', playLabel('REJOIN'));
    b.disabled = playDisabled(last);
    b.onclick = () => startPlay(last);
    hero.append(b);
  } else {
    txt.append(el('div', 'h-kicker', name ? `Welcome, ${name}` : 'Welcome, survivor'));
    txt.append(el('div', 'h-name', 'Pick a server'));
    txt.append(el('div', 'h-empty', 'Choose a server below. The launcher downloads any mods you need and remembers where you played last.'));
    hero.append(txt);
  }
  box.append(hero);
}

function renderServers() {
  const box = $('servers'); box.replaceChildren();
  if (!S.serverList.length) { box.append(el('div', 'empty', 'No servers listed yet.')); return; }
  const groups = (S.serverGroups && S.serverGroups.length) ? S.serverGroups : [{ id: '', title: 'Servers' }];
  const known = new Set(groups.map((g) => g.id));
  // Servers with no group (or an unknown one) go under the first heading.
  const inGroup = (s, g, i) => s.group === g.id || (i === 0 && !known.has(s.group));
  $('firstGroupTitle').textContent = groups[0].title;
  groups.forEach((g, i) => {
    const list = S.serverList.filter((s) => inGroup(s, g, i));
    if (!list.length && i > 0) return;
    const section = el('div', 'server-group');
    if (i > 0) section.append(el('h2', null, g.title));
    const cards = el('div', 'servers');
    section.append(cards);
    box.append(section);
    if (!list.length) cards.append(el('div', 'empty', 'No servers here yet.'));
    renderServerCards(list, cards);
  });
}

function renderServerCards(list, box) {
  for (const s of list) {
    const c = el('div', `card${s.id === S.settings.lastServerId ? ' last' : ''}`);
    c.append(el('div', lightClass(s)));
    const mid = el('div');
    const nm = el('div', 'c-name', s.name);
    if (s.id === S.settings.lastServerId) nm.append(el('span', 'tag gold', 'Last played'));
    if (s.status && s.status.info && s.status.info.passworded) nm.append(el('span', 'tag lock', s.hasPassword ? '🔒 Password saved' : '🔒 Password'));
    mid.append(nm);
    const meta = el('div', 'c-meta');
    if (s.status && s.status.up) {
      const i = s.status.info;
      const p = el('span'); p.append(el('b', null, `${i.players}/${i.maxPlayers}`), document.createTextNode(' online')); meta.append(p);
      if (i.map) meta.append(el('span', null, mapName(i.map)));
      if (i.time) meta.append(el('span', null, `🕓 ${i.time}`));
      meta.append(el('span', null, `${i.ping} ms`));
    } else if (s.status) {
      meta.append(el('span', null, 'Offline or restarting'));
    } else meta.append(el('span', null, 'Checking…'));
    if (s.description) meta.append(el('span', null, s.description));
    mid.append(meta);
    c.append(mid);
    const mods = el('div', 'c-mods'); mods.append(modLine(s)); c.append(mods);
    const actions = el('div', 'c-actions');
    if (s.status && s.status.info && s.status.info.passworded) {
      const k = el('button', 'icon-btn', '🔑');
      k.title = 'Enter or change the server password';
      k.onclick = () => openPw(s.id, 'edit');
      actions.append(k);
    }
    const b = el('button', 'btn-play small', playLabel('PLAY'));
    b.disabled = playDisabled(s);
    b.onclick = () => startPlay(s);
    actions.append(b);
    c.append(actions);
    box.append(c);
  }
}

// --- Discord-style text: **bold**, *italic*, __underline__, ~~strike~~, `code`, links, timestamps ---
function fmtTs(sec, style) {
  const d = new Date(Number(sec) * 1000);
  if (Number.isNaN(d.getTime())) return '';
  const o = {
    t: { hour: 'numeric', minute: '2-digit' },
    T: { hour: 'numeric', minute: '2-digit', second: '2-digit' },
    d: { month: 'numeric', day: 'numeric', year: 'numeric' },
    D: { month: 'long', day: 'numeric', year: 'numeric' },
    f: { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' },
    F: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' },
  };
  if (style === 'R') return relTime(d);
  return d.toLocaleString(undefined, o[style] || o.f);
}
function relTime(d) {
  const diff = (d.getTime() - Date.now()) / 1000;
  const a = Math.abs(diff);
  const units = [[60, 'second', 1], [3600, 'minute', 60], [86400, 'hour', 3600], [2592000, 'day', 86400], [31536000, 'month', 2592000], [Infinity, 'year', 31536000]];
  for (const [lim, unit, div] of units) {
    if (a < lim) {
      const n = Math.max(1, Math.round(a / div));
      return diff < 0 ? `${n} ${unit}${n > 1 ? 's' : ''} ago` : `in ${n} ${unit}${n > 1 ? 's' : ''}`;
    }
  }
  return d.toLocaleDateString();
}
function linkEl(text, url) {
  const a = el('a', null, text);
  a.title = url;
  a.onclick = (e) => { e.preventDefault(); e.stopPropagation(); owg.openUrl(url); };
  return a;
}
const INLINE = /(\*\*[^*]+\*\*|__[^_]+__|~~[^~]+~~|`[^`]+`|\*[^*\s][^*]*\*|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|https?:\/\/[^\s<>()]+|\{\{ts:\d+:[a-zA-Z]\}\})/g;
function inline(text, parent) {
  let last = 0;
  for (const m of text.matchAll(INLINE)) {
    if (m.index > last) parent.append(document.createTextNode(text.slice(last, m.index)));
    const t = m[0];
    if (t.startsWith('**')) { const b = el('b'); inline(t.slice(2, -2), b); parent.append(b); }
    else if (t.startsWith('__')) { const u = el('u'); inline(t.slice(2, -2), u); parent.append(u); }
    else if (t.startsWith('~~')) { const x = el('s'); inline(t.slice(2, -2), x); parent.append(x); }
    else if (t.startsWith('`')) parent.append(el('code', null, t.slice(1, -1)));
    else if (t.startsWith('*')) { const i = el('i'); inline(t.slice(1, -1), i); parent.append(i); }
    else if (t.startsWith('[')) { const mm = t.match(/^\[([^\]]+)\]\((.+)\)$/); parent.append(linkEl(mm[1], mm[2])); }
    else if (t.startsWith('{{ts:')) { const mm = t.match(/ts:(\d+):(\w)/); parent.append(el('span', 'an-ts', fmtTs(mm[1], mm[2]))); }
    else parent.append(linkEl(t, t));
    last = m.index + t.length;
  }
  if (last < text.length) parent.append(document.createTextNode(text.slice(last)));
}
function richText(text) {
  const box = el('div', 'an-body');
  const lines = String(text || '').split('\n');
  lines.forEach((line, i) => {
    const h = line.match(/^#{1,3}\s+(.*)$/);
    if (h) { const d = el('div', 'h'); inline(h[1], d); box.append(d); return; }
    const li = line.match(/^\s*[-*]\s+(.*)$/);
    const target = li ? (() => { box.append(document.createTextNode('• ')); return box; })() : box;
    inline(li ? li[1] : line.replace(/^>\s?/, ''), target);
    if (i < lines.length - 1) box.append(document.createTextNode('\n'));
  });
  return box;
}

let annKey = '';
function renderAnnouncements() {
  const list = S.announcements || [];
  // Rebuild only when something changed (or once a minute for "5 minutes ago" times),
  // so the highlight animation isn't restarted on every status refresh.
  const key = JSON.stringify(list) + (S.discord && S.discord.channel) + Math.floor(Date.now() / 60000);
  if (key === annKey) return;
  annKey = key;
  const box = $('announcements'); box.replaceChildren();
  const unread = list.filter((a) => a.unread).length;
  $('annTools').classList.toggle('hidden', unread === 0);
  $('annUnread').textContent = unread ? `${unread} new` : '';
  $('annSource').textContent = S.discord && S.discord.channel ? `From Discord #${S.discord.channel}` : '';
  if (!list.length) { box.append(el('div', 'empty', 'No announcements right now.')); return; }
  for (const a of list) {
    const d = el('div', `ann${a.pinned ? ' pinned' : ''}${a.unread ? ' unread' : ''}`);
    const top = el('div', 'an-top');
    if (a.kind === 'discord') {
      const who = el('div', 'an-author');
      if (a.unread) who.append(el('span', 'tag new', 'NEW'));
      who.append(document.createTextNode(a.author || 'Discord'));
      top.append(who);
      const dt = new Date(a.date);
      const when = el('div', 'an-date', relTime(dt));
      when.title = dt.toLocaleString() + (a.edited ? ' (edited)' : '');
      top.append(when);
      d.append(top);
      if (a.text) d.append(richText(a.text));
      const foot = el('div', 'an-foot');
      foot.append(el('span', null, a.attachments.length ? `📎 ${a.attachments.join(', ')}` : (a.edited ? 'edited' : '')));
      if (a.url) { const l = el('span', 'an-link', 'View in Discord'); l.onclick = (e) => { e.stopPropagation(); owg.openUrl(a.url); }; foot.append(l); }
      d.append(foot);
      if (a.unread) { d.title = 'Click to mark as read'; d.onclick = () => owg.markRead(a.id); }
    } else {
      top.append(el('div', 'an-title', `${a.pinned ? '📌 ' : ''}${a.title || ''}`));
      if (a.date) top.append(el('div', 'an-date', a.date));
      d.append(top);
      if (a.text) d.append(richText(a.text));
    }
    box.append(d);
  }
}

// --- "Attention!" alert: chime, then a spoken "Attention!" ---
let alertBusy = false;
function speakAttention() {
  return new Promise((resolve) => {
    const synth = window.speechSynthesis;
    const fallback = () => { const a = new Audio('sounds/attention-fallback.wav'); a.volume = 0.9; a.onended = resolve; a.onerror = resolve; a.play().catch(resolve); };
    if (!synth) return fallback();
    const go = () => {
      const voices = synth.getVoices().filter((v) => /^en/i.test(v.lang));
      if (!voices.length) return fallback();
      const pick = voices.find((v) => /david|guy|mark|george|ryan|male/i.test(v.name)) || voices[0];
      const u = new SpeechSynthesisUtterance('Attention!');
      u.voice = pick; u.rate = 0.92; u.pitch = 0.75; u.volume = 1;
      u.onend = resolve; u.onerror = fallback;
      synth.cancel(); synth.speak(u);
      setTimeout(resolve, 4000);
    };
    if (synth.getVoices().length) go();
    else { let done = false; synth.onvoiceschanged = () => { if (!done) { done = true; go(); } }; setTimeout(() => { if (!done) { done = true; go(); } }, 700); }
  });
}
async function playAttention() {
  if (alertBusy) return;
  alertBusy = true;
  try {
    await new Promise((resolve) => { const c = new Audio('sounds/chime.wav'); c.volume = 0.8; c.onended = resolve; c.onerror = resolve; c.play().catch(resolve); });
    await speakAttention();
  } finally { alertBusy = false; }
}

function renderOverlay() {
  const ov = $('overlay');
  const p = S.play;
  if (p && p.phase === 'password') {
    // Main process found the server needs a password: ask for it.
    owg.dismiss();
    if (!pwPrompt) openPw(p.serverId, 'join');
    ov.classList.add('hidden');
    return;
  }
  if (!p) { ov.classList.add('hidden'); return; }
  ov.classList.remove('hidden');
  const srv = S.serverList.find((s) => s.id === p.serverId);
  const sname = srv ? srv.name : '';
  const titles = { prepare: `Joining ${sname}`, mods: `Getting mods for ${sname}`, launch: 'Launching DayZ', launched: 'Launching DayZ', error: 'Can’t join yet', ready: 'Mods ready' };
  $('ovTitle').textContent = titles[p.phase] || `Joining ${sname}`;
  $('ovMsg').textContent = p.error || p.message || '';

  const bar = $('ovBar');
  if (p.active && p.phase === 'mods' && p.percent !== null && p.percent !== undefined) {
    bar.classList.remove('hidden'); $('ovBarFill').style.width = `${p.percent}%`;
  } else bar.classList.add('hidden');

  const items = $('ovItems'); items.replaceChildren();
  if (p.active && p.items && p.items.length) {
    for (const i of p.items) {
      const r = el('div', 'ov-item');
      r.append(el('span', null, i.name));
      let st = 'Queued in Steam';
      if (i.downloading && i.total) st = `${pct(i.current, i.total)}% · ${mb(i.current)} / ${mb(i.total)}`;
      else if (i.downloading) st = 'Downloading…';
      r.append(el('span', 'st', st));
      items.append(r);
    }
  }

  const hint = $('ovHint');
  if (p.active && p.stuck) {
    hint.textContent = 'Steam hasn’t made progress for a minute. Open Steam’s Downloads page and make sure downloads aren’t paused. If Steam is set to only download while no game is running, close any running game.';
    hint.classList.remove('hidden');
  } else hint.classList.add('hidden');

  const act = $('ovActions'); act.replaceChildren();
  if (p.active) {
    const c = el('button', 'btn-secondary', 'Cancel');
    c.onclick = () => owg.cancel();
    act.append(c);
  } else {
    if (p.storeAppIds && p.storeAppIds.length) {
      const s = el('button', 'btn-secondary', 'Open in Steam Store');
      s.onclick = () => owg.openUrl(`steam://store/${p.storeAppIds[0]}`);
      act.append(s);
    }
    if (p.phase === 'ready' && p.serverId) {
      const j = el('button', 'btn-play small', 'PLAY NOW');
      j.onclick = () => owg.play(p.serverId);
      act.append(j);
    }
    const c = el('button', 'btn-secondary', 'Close');
    c.onclick = () => owg.dismiss();
    act.append(c);
  }
}

function renderFooter() {
  const input = $('playerName');
  if (document.activeElement !== input) input.value = S.settings.playerName || '';
  $('autoJoin').checked = S.settings.autoJoin !== false;
  $('minimizeOnLaunch').checked = S.settings.minimizeOnLaunch === true;
  $('sounds').checked = S.settings.sounds !== false;
  $('version').textContent = `v${S.version}`;
  const st = $('steamStatus');
  st.replaceChildren();
  const dot = el('span', S.steamRunning ? 'light up' : 'light down');
  dot.style.width = '8px'; dot.style.height = '8px';
  st.append(dot, document.createTextNode(S.steamRunning ? 'Steam connected' : 'Steam not running'));
}

function render(state) {
  S = state;
  renderAlerts();
  renderHero();
  renderServers();
  renderAnnouncements();
  renderOverlay();
  renderFooter();
  syncJoin();
}

document.querySelectorAll('[data-win]').forEach((b) => { b.onclick = () => owg.win(b.dataset.win); });
$('refreshBtn').onclick = () => owg.refresh();
$('playerName').addEventListener('input', (e) => {
  clearTimeout(nameTimer);
  nameTimer = setTimeout(() => owg.saveSettings({ playerName: e.target.value.trim() }), 500);
});
$('autoJoin').addEventListener('change', (e) => owg.saveSettings({ autoJoin: e.target.checked }));
$('minimizeOnLaunch').addEventListener('change', (e) => owg.saveSettings({ minimizeOnLaunch: e.target.checked }));
$('sounds').addEventListener('change', (e) => { owg.saveSettings({ sounds: e.target.checked }); if (e.target.checked) playAttention(); });
$('markAllRead').onclick = () => owg.markRead('all');
owg.onAlert(() => { if (!S || S.settings.sounds !== false) playAttention(); });
$('pwShow').addEventListener('change', (e) => { $('pwInput').type = e.target.checked ? 'text' : 'password'; });
$('pwCancel').onclick = closePw;
$('pwForget').onclick = async () => { if (!pwPrompt) return; await owg.setPassword(pwPrompt.serverId, '', false); closePw(); };
$('pwForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!pwPrompt) return;
  const pw = $('pwInput').value;
  if (!pw) { $('pwInput').focus(); return; }
  const { serverId, mode } = pwPrompt;
  const remember = $('pwRemember').checked;
  closePw();
  if (mode === 'join') owg.play(serverId, { password: pw, remember });
  else owg.setPassword(serverId, pw, remember);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && pwPrompt) closePw(); });


// ---------- join screen (cinematic overlay after Play / Rejoin) ----------
const JOIN = { open: false, token: null, serverId: null, timer: null, slideTimer: null, slides: [], idx: 0, raf: null, launched: false };

function joinSlidesFor(srv) {
  const j = srv.join || {};
  if (j.media && j.media.length) return j.media.map((m) => ({ url: m.url, kind: m.kind }));
  // No media set for this server: show only this server's own artwork (or the OWG logo if it has none).
  if (srv.imageUrl) return [{ url: srv.imageUrl, kind: 'image' }];
  return [{ url: 'logo.png', kind: 'image', fit: true }];
}

function buildMessage(text, serverName) {
  const box = $('joinMessage'); box.replaceChildren();
  const parts = String(text).split('{server}');
  let i = 0;
  const addWords = (str, cls) => {
    str.split(/(\s+)/).forEach((w) => {
      if (!w) return;
      if (/^\s+$/.test(w)) { box.append(document.createTextNode(' ')); return; }
      const word = el('span', cls || null); word.style.cssText = 'opacity:1;transform:none;filter:none;animation:none;white-space:nowrap';
      for (const ch of w) { const c = el('span', null, ch); c.style.animationDelay = `${0.5 + i++ * 0.035}s`; word.append(c); }
      box.append(word);
    });
  };
  parts.forEach((p, k) => { addWords(p); if (k < parts.length - 1) addWords(serverName, 'srv'); });
}

function showSlide(n) {
  const stage = $('joinStage');
  const slides = JOIN.slides;
  if (!slides.length) return;
  JOIN.idx = (n + slides.length) % slides.length;
  const def = slides[JOIN.idx];
  const dur = (JOIN.slideSeconds || 6);
  const node = el('div', `join-slide${JOIN.idx % 2 ? ' alt' : ''}`);
  node.style.setProperty('--dur', `${dur + 2}s`);
  let next = dur * 1000;
  if (def.kind === 'video') {
    const v = document.createElement('video');
    v.src = def.url; v.muted = true; v.autoplay = true; v.playsInline = true; v.loop = slides.length === 1;
    v.addEventListener('loadedmetadata', () => {
      if (slides.length > 1 && Number.isFinite(v.duration)) { clearTimeout(JOIN.slideTimer); JOIN.slideTimer = setTimeout(() => showSlide(JOIN.idx + 1), Math.min(v.duration, 45) * 1000 - 900); }
    });
    v.addEventListener('error', () => { if (slides.length > 1) { clearTimeout(JOIN.slideTimer); showSlide(JOIN.idx + 1); } });
    node.append(v);
    next = 45000;
  } else {
    const bg = el('div', 'bg'); bg.style.backgroundImage = `url("${def.url}")`;
    node.append(bg);
    const decide = (fit) => {
      if (!fit) return;
      node.classList.add('fit');
      const fg = el('div', 'fg'); fg.style.backgroundImage = `url("${def.url}")`; node.append(fg);
    };
    if (def.fit) decide(true);
    else { const probe = new Image(); probe.onload = () => decide(probe.naturalWidth / probe.naturalHeight < 1.3); probe.src = def.url; }
  }
  stage.append(node);
  requestAnimationFrame(() => requestAnimationFrame(() => node.classList.add('show')));
  // Fade out and remove the previous slide.
  [...stage.children].slice(0, -1).forEach((old) => { old.classList.remove('show'); setTimeout(() => old.remove(), 2000); });
  clearTimeout(JOIN.slideTimer);
  if (slides.length > 1) JOIN.slideTimer = setTimeout(() => showSlide(JOIN.idx + 1), next);
}

function startParticles() {
  const cv = $('joinParticles'); const ctx = cv.getContext('2d');
  const dots = [];
  const resize = () => { cv.width = cv.clientWidth * devicePixelRatio; cv.height = cv.clientHeight * devicePixelRatio; };
  resize();
  for (let i = 0; i < 70; i++) dots.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.8 + 0.4, v: Math.random() * 0.00035 + 0.00012, d: Math.random() * Math.PI * 2, a: Math.random() * 0.5 + 0.15 });
  const tick = () => {
    if (!JOIN.open) return;
    if (cv.width !== cv.clientWidth * devicePixelRatio) resize();
    ctx.clearRect(0, 0, cv.width, cv.height);
    for (const p of dots) {
      p.y -= p.v; p.d += 0.01; p.x += Math.sin(p.d) * 0.0003;
      if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
      const g = ctx.createRadialGradient(p.x * cv.width, p.y * cv.height, 0, p.x * cv.width, p.y * cv.height, p.r * 4 * devicePixelRatio);
      g.addColorStop(0, `rgba(255,214,90,${p.a})`); g.addColorStop(1, 'rgba(255,214,90,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x * cv.width, p.y * cv.height, p.r * 4 * devicePixelRatio, 0, Math.PI * 2); ctx.fill();
    }
    JOIN.raf = requestAnimationFrame(tick);
  };
  tick();
}

function openJoin(srv, token) {
  const j = srv.join || {};
  if (j.enabled === false) { JOIN.token = token; return; }
  closeJoin(true);
  Object.assign(JOIN, { open: true, token, serverId: srv.id, launched: false, slideSeconds: j.slideSeconds || 6, slides: joinSlidesFor(srv) });
  $('joinStage').replaceChildren();
  buildMessage(j.message || 'You are joining "{server}". Prepare to survive or die trying.', srv.name);
  const scr = $('joinScreen'); scr.classList.remove('hidden', 'closing');
  showSlide(0);
  startParticles();
  JOIN.timer = setTimeout(() => closeJoin(), (j.maxSeconds || 120) * 1000);
  updateJoinStatus();
}

function closeJoin(instant) {
  if (!JOIN.open) return;
  JOIN.open = false;
  clearTimeout(JOIN.timer); clearTimeout(JOIN.slideTimer); cancelAnimationFrame(JOIN.raf);
  const scr = $('joinScreen');
  const finish = () => { scr.classList.add('hidden'); scr.classList.remove('closing'); $('joinStage').replaceChildren(); };
  if (instant) finish(); else { scr.classList.add('closing'); setTimeout(finish, 600); }
}

function updateJoinStatus() {
  if (!JOIN.open) return;
  const p = S.play;
  const bar = $('joinBarFill').parentElement;
  let text = 'Getting ready…'; let pctVal = null;
  if (p && p.active) {
    text = p.message || text;
    if (p.phase === 'mods' && p.percent !== null && p.percent !== undefined) pctVal = p.percent;
  } else if (S.gameRunning) { text = 'DayZ is running. See you out there.'; pctVal = 100; JOIN.launched = true; }
  else if (S.launching || (p && p.phase === 'launched')) { text = 'Starting DayZ… this can take a minute.'; JOIN.launched = true; }
  bar.classList.toggle('indeterminate', pctVal === null);
  $('joinBarFill').style.width = pctVal === null ? '' : `${pctVal}%`;
  $('joinStatus').textContent = text;
}

function syncJoin() {
  const p = S.play;
  if (p && p.active && p.token && p.token !== JOIN.token) {
    const srv = S.serverList.find((x) => x.id === p.serverId);
    if (srv) openJoin(srv, p.token);
  }
  if (!JOIN.open) return;
  // Close early only when the join can't go ahead: an error, a password prompt, a cancel,
  // or "mods ready" with auto-join off. Otherwise it stays up for the full time.
  if (p && ['error', 'password', 'ready'].includes(p.phase)) return closeJoin();
  if (!p && !JOIN.launched && !S.launching && !S.gameRunning) return closeJoin();
  updateJoinStatus();
}
$('joinClose').onclick = () => closeJoin();
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && JOIN.open) closeJoin(); });

// --- help window ---
let helpIndex = 0;
function showHelp(i) {
  const topics = window.OWG_HELP || [];
  if (!topics.length) return;
  helpIndex = Math.max(0, Math.min(topics.length - 1, i));
  const nav = $('helpNav'); nav.replaceChildren();
  topics.forEach((t, k) => {
    const b = el('button', k === helpIndex ? 'active' : '');
    b.append(el('span', 'n', t.n + '.'), el('span', null, t.title));
    b.onclick = () => showHelp(k);
    nav.append(b);
  });
  const t = topics[helpIndex];
  const c = $('helpContent'); c.replaceChildren(el('h3', null, t.title), el('pre', null, t.body));
  const pager = el('div', 'help-pager');
  const prev = el('button', 'btn-secondary', '← Previous'); prev.disabled = helpIndex === 0; prev.onclick = () => showHelp(helpIndex - 1);
  const next = el('button', 'btn-secondary', 'Next →'); next.disabled = helpIndex === topics.length - 1; next.onclick = () => showHelp(helpIndex + 1);
  if (helpIndex === 0) prev.style.visibility = 'hidden';
  if (helpIndex === topics.length - 1) next.style.visibility = 'hidden';
  pager.append(prev, next); c.append(pager);
  c.scrollTop = 0;
  $('helpOverlay').classList.remove('hidden');
}
function closeHelp() { $('helpOverlay').classList.add('hidden'); }
$('helpBtn').onclick = () => showHelp(helpIndex);
$('helpClose').onclick = closeHelp;
$('helpOverlay').addEventListener('mousedown', (e) => { if (e.target === $('helpOverlay')) closeHelp(); });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('helpOverlay').classList.contains('hidden')) closeHelp();
  if (e.key === 'F1') { e.preventDefault(); showHelp(helpIndex); }
});

owg.onState(render);
owg.getState().then(render);
