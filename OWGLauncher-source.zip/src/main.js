'use strict';
const { app, BrowserWindow, ipcMain, shell, Notification, safeStorage, protocol, net } = require('electron');
const { pathToFileURL } = require('url');
const path = require('path');
const fs = require('fs');
const dns = require('dns').promises;
const { fork, spawn } = require('child_process');
const crypto = require('crypto');
const a2s = require('./a2s');
const steamLocal = require('./steam-local');

const CONFIG_URL = 'https://raw.githubusercontent.com/XCITEDMAN/OWGLauncher/main/servers.json';
const CONFIG_REFRESH_MS = 10 * 60 * 1000;
const STATUS_REFRESH_MS = 30 * 1000;
const MODLIST_REFRESH_MS = 2 * 60 * 1000;
const MODCHECK_IDLE_MS = 60 * 1000;
const MODCHECK_ACTIVE_MS = 3 * 1000;

app.setAppUserModelId('com.olderwisergamers.launcher');
if (!app.requestSingleInstanceLock()) { app.quit(); }
// owg-img:// serves the cached server artwork to the window.
protocol.registerSchemesAsPrivileged([{ scheme: 'owg-img', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } }]);

let win = null;
const dataDir = () => app.getPath('userData');
const dataFile = (n) => path.join(dataDir(), n);
const readJson = (file, fallback) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } };
const writeJson = (file, obj) => { try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(obj, null, 2)); } catch {} };

// ---------------- state ----------------
const state = {
  version: app.getVersion(),
  config: null,
  configSource: null, // 'live' | 'cache' | 'builtin'
  configError: null,
  servers: {}, // id -> { up, info, ip, error, lastSeen }
  mods: {}, // serverId -> [{id,name,dlc}]
  modSource: {}, // serverId -> 'live' | 'cache' | 'config'
  modStatus: {}, // workshopId -> status
  steamRunning: null,
  dayzFound: null,
  gameRunning: false,
  launching: null, // { serverId, at } from the moment DayZ is started until its window process appears
  settings: { lastServerId: null, playerName: '', autoJoin: true, extraParams: '', minimizeOnLaunch: false, passwords: {}, sounds: true, lastAnnouncementId: null, unreadAnnouncements: [] },
  discord: null, // { channel, updated, items: [...] } from announcements.json
  play: null, // in-progress play flow
  updateAvailable: null, // fallback: manual download link from servers.json
  update: null, // { version, notes, status: 'downloading'|'ready'|'installing', percent }
};

function push() { if (win && !win.isDestroyed()) win.webContents.send('state', publicState()); }
function publicState() {
  const { config, settings, ...rest } = state;
  const { passwords, ...safeSettings } = settings;
  return { ...rest, settings: safeSettings, announcements: activeAnnouncements(), serverList: serverList(), serverGroups: serverGroups() };
}

function serverList() {
  if (!state.config) return [];
  const def = state.config.defaultHost;
  return (state.config.servers || [])
    .filter((s) => s && s.enabled !== false && s.id)
    .sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
    .map((s) => ({
      id: s.id, name: s.name || s.id, host: s.host || def, gamePort: s.gamePort, queryPort: s.queryPort,
      description: s.description || '',
      group: String(s.group || ''),
      imageUrl: serverImages[s.id] ? `owg-img://art/${encodeURIComponent(s.id)}?v=${serverImages[s.id].hash}` : null,
      imageOpacity: Number.isFinite(Number(s.imageOpacity)) ? Math.min(1, Math.max(0.03, Number(s.imageOpacity))) : null,
      join: joinScreenFor(s),
      configMods: Array.isArray(s.mods) ? s.mods : null, modsOverride: Boolean(s.modsOverride),
      hasPassword: Boolean(getPassword(s.id)),
      perspective: ['1pp', '3pp'].includes(String(s.perspective || '').toLowerCase()) ? String(s.perspective).toLowerCase() : null,
      status: state.servers[s.id] || null,
      mods: state.mods[s.id] || [],
      modSource: state.modSource[s.id] || null,
      modSummary: modSummary(s.id),
    }));
}

// Headings for the server list, from servers.json "groups": [{ "id": "hived", "title": "Hived Servers" }, ...].
// Servers pick one with "group": "hived". Without groups, everything sits under "Servers".
function serverGroups() {
  const raw = (state.config && Array.isArray(state.config.groups)) ? state.config.groups : [];
  const groups = raw.filter((g) => g && g.id).map((g) => ({ id: String(g.id), title: String(g.title || g.id) }));
  if (!groups.length) return [{ id: '', title: 'Servers' }];
  return groups;
}

function activeAnnouncements() {
  const list = (state.config && state.config.announcements) || [];
  const today = new Date().toISOString().slice(0, 10);
  const manual = list
    .filter((a) => a && (a.title || a.body) && (!a.expires || a.expires >= today))
    .map((a) => ({ kind: 'manual', id: `m:${a.id || a.title}`, title: a.title || '', text: a.body || '', date: a.date || null, pinned: Boolean(a.pinned) }));
  const unread = new Set(state.settings.unreadAnnouncements || []);
  const discord = ((state.discord && state.discord.items) || []).map((m) => ({
    kind: 'discord', id: m.id, author: m.author || '', text: m.text || '', date: m.timestamp, edited: m.edited,
    attachments: Array.isArray(m.attachments) ? m.attachments : [], url: m.url || null, unread: unread.has(m.id), pinned: false,
  }));
  const t = (x) => { const v = Date.parse(x.date || ''); return Number.isNaN(v) ? 0 : v; };
  return [...manual, ...discord].sort((a, b) => (Number(b.pinned) - Number(a.pinned)) || (t(b) - t(a)));
}

function modSummary(serverId) {
  const mods = (state.mods[serverId] || []).filter((m) => !m.dlc);
  if (!mods.length) return { total: 0, ready: 0, missing: 0, updating: [], unknown: !state.mods[serverId] };
  let ready = 0; let missing = 0; const updating = [];
  for (const m of mods) {
    const st = state.modStatus[m.id];
    if (!st) continue;
    if (st.ready) ready++;
    else if (st.downloading || st.needsUpdate) updating.push({ id: m.id, name: m.name || st.title || m.id, current: st.current, total: st.total, downloading: st.downloading });
    else if (!st.installed) missing++;
  }
  return { total: mods.length, ready, missing, updating };
}

// ---------------- config ----------------
function normalizeConfig(cfg) {
  if (!cfg || typeof cfg !== 'object' || !Array.isArray(cfg.servers)) throw new Error('servers list missing');
  return cfg;
}

// ---------------- server artwork ----------------
// servers.json: "image": "images/deadfall.png" (a file in the GitHub repo) or a full https:// link.
const serverImages = {}; // id -> { file, hash, src }
const IMG_MAX = 5 * 1024 * 1024;
const IMG_TYPES = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
function imageSrc(img) {
  const v = String(img || '').trim();
  if (!v) return null;
  if (/^https:\/\//i.test(v)) return v;
  if (/^[\w./ -]+$/.test(v) && !v.includes('..')) return `https://raw.githubusercontent.com/XCITEDMAN/OWGLauncher/main/${v.replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/')}`;
  return null;
}
const imgIndexFile = () => dataFile('images/index.json');
async function refreshImages() {
  const dir = dataFile('images');
  fs.mkdirSync(dir, { recursive: true });
  const index = readJson(imgIndexFile(), {});
  let changed = false;
  for (const s of (state.config && state.config.servers) || []) {
    if (!s || !s.id) continue;
    const src = imageSrc(s.image);
    if (!src) { if (serverImages[s.id]) { delete serverImages[s.id]; changed = true; } continue; }
    const cached = index[s.id];
    if (cached && cached.src === src && fs.existsSync(cached.file)) {
      if (!serverImages[s.id] || serverImages[s.id].hash !== cached.hash) { serverImages[s.id] = cached; changed = true; }
      if (Date.now() - (cached.at || 0) < 6 * 3600 * 1000) continue; // re-check at most every 6 hours
    }
    try {
      const res = await fetch(`${src}${src.includes('?') ? '&' : '?'}t=${Date.now()}`, { signal: AbortSignal.timeout(20000) });
      const type = String(res.headers.get('content-type') || '').split(';')[0].trim();
      if (!res.ok || !IMG_TYPES[type]) throw new Error('not an image');
      const buf = Buffer.from(await res.arrayBuffer());
      if (!buf.length || buf.length > IMG_MAX) throw new Error('image too large');
      const hash = crypto.createHash('sha256').update(buf).digest('hex').slice(0, 16);
      const file = path.join(dir, `${s.id.replace(/[^\w-]/g, '_')}-${hash}.${IMG_TYPES[type]}`);
      if (!fs.existsSync(file)) fs.writeFileSync(file, buf);
      if (cached && cached.file !== file) { try { fs.unlinkSync(cached.file); } catch {} }
      index[s.id] = { file, hash, src, at: Date.now() };
      if (!serverImages[s.id] || serverImages[s.id].hash !== hash) changed = true;
      serverImages[s.id] = index[s.id];
    } catch { /* keep the cached copy, if any */ }
  }
  writeJson(imgIndexFile(), index);
  if (changed) push();
}

// ---------------- join screen (cinematic overlay shown after Play/Rejoin) ----------------
// servers.json: "joinScreen": { "message": "...{server}...", "media": ["join/a.jpg", "join/b.mp4"],
// "slideSeconds": 6, "maxSeconds": 120 } at the top level (default) and/or inside a server (override).
const DEFAULT_JOIN_MESSAGE = 'You are joining "{server}". Prepare to survive or die trying.';
const MEDIA_TYPES = { ...IMG_TYPES, 'video/mp4': 'mp4', 'video/webm': 'webm' };
const MEDIA_MAX = { image: 8 * 1024 * 1024, video: 60 * 1024 * 1024 };
const mediaCache = {}; // src -> { file, hash, kind, at }
const mediaIndexFile = () => dataFile('media/index.json');

function joinSettings(s) {
  const base = (state.config && state.config.joinScreen) || {};
  const own = (s && s.joinScreen) || {};
  const pick = (k) => (own[k] !== undefined ? own[k] : base[k]);
  const num = (v, d, lo, hi) => (Number.isFinite(Number(v)) ? Math.min(hi, Math.max(lo, Number(v))) : d);
  return {
    enabled: pick('enabled') !== false,
    message: String(pick('message') || DEFAULT_JOIN_MESSAGE).slice(0, 300),
    media: (Array.isArray(own.media) && own.media.length ? own.media : (Array.isArray(base.media) ? base.media : [])).slice(0, 30),
    slideSeconds: num(pick('slideSeconds'), 6, 2, 60),
    maxSeconds: num(pick('maxSeconds'), 120, 5, 600),
  };
}

function joinScreenFor(s) {
  const j = joinSettings(s);
  const media = [];
  for (const m of j.media) {
    const src = imageSrc(m);
    const c = src && mediaCache[src];
    if (c && fs.existsSync(c.file)) media.push({ url: `owg-img://media/${c.hash}.${path.extname(c.file).slice(1)}`, kind: c.kind });
  }
  return { enabled: j.enabled, message: j.message, slideSeconds: j.slideSeconds, maxSeconds: j.maxSeconds, media };
}

async function refreshJoinMedia() {
  const dir = dataFile('media');
  fs.mkdirSync(dir, { recursive: true });
  Object.assign(mediaCache, readJson(mediaIndexFile(), {}));
  const wanted = new Set();
  const cfg = state.config || {};
  for (const m of joinSettings(null).media) { const src = imageSrc(m); if (src) wanted.add(src); }
  for (const s of cfg.servers || []) for (const m of ((s && s.joinScreen && s.joinScreen.media) || [])) { const src = imageSrc(m); if (src) wanted.add(src); }
  let changed = false;
  for (const src of wanted) {
    const c = mediaCache[src];
    if (c && fs.existsSync(c.file) && Date.now() - (c.at || 0) < 6 * 3600 * 1000) continue;
    try {
      const res = await fetch(`${src}${src.includes('?') ? '&' : '?'}t=${Date.now()}`, { signal: AbortSignal.timeout(10 * 60 * 1000) });
      const type = String(res.headers.get('content-type') || '').split(';')[0].trim();
      const ext = MEDIA_TYPES[type] || ({ mp4: 'mp4', webm: 'webm', jpg: 'jpg', jpeg: 'jpg', png: 'png', webp: 'webp', gif: 'gif' })[src.split('?')[0].split('.').pop().toLowerCase()];
      if (!res.ok || !ext) throw new Error('unsupported');
      const kind = ext === 'mp4' || ext === 'webm' ? 'video' : 'image';
      const buf = Buffer.from(await res.arrayBuffer());
      if (!buf.length || buf.length > MEDIA_MAX[kind]) throw new Error('too large');
      const hash = crypto.createHash('sha256').update(buf).digest('hex').slice(0, 20);
      const file = path.join(dir, `${hash}.${ext}`);
      if (!fs.existsSync(file)) fs.writeFileSync(file, buf);
      if (c && c.file !== file) { try { fs.unlinkSync(c.file); } catch {} }
      if (!c || c.hash !== hash) changed = true;
      mediaCache[src] = { file, hash, kind, at: Date.now() };
    } catch { /* keep any cached copy */ }
  }
  // Forget media no longer listed.
  for (const src of Object.keys(mediaCache)) {
    if (!wanted.has(src)) { try { fs.unlinkSync(mediaCache[src].file); } catch {} delete mediaCache[src]; changed = true; }
  }
  writeJson(mediaIndexFile(), mediaCache);
  if (changed) push();
}

// Serves cached files to the window, with byte ranges so videos can stream.
function serveFile(file, req) {
  let stat;
  try { stat = fs.statSync(file); } catch { return new Response('', { status: 404 }); }
  const ext = path.extname(file).slice(1).toLowerCase();
  const type = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', mp4: 'video/mp4', webm: 'video/webm' }[ext] || 'application/octet-stream';
  const range = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  const { Readable } = require('stream');
  if (range) {
    let start = range[1] ? Number(range[1]) : 0;
    let end = range[2] ? Number(range[2]) : stat.size - 1;
    if (!range[1] && range[2]) { start = Math.max(0, stat.size - Number(range[2])); end = stat.size - 1; }
    end = Math.min(end, stat.size - 1);
    if (start > end) return new Response('', { status: 416, headers: { 'Content-Range': `bytes */${stat.size}` } });
    return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })), {
      status: 206,
      headers: { 'Content-Type': type, 'Content-Length': String(end - start + 1), 'Content-Range': `bytes ${start}-${end}/${stat.size}`, 'Accept-Ranges': 'bytes' },
    });
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)), { status: 200, headers: { 'Content-Type': type, 'Content-Length': String(stat.size), 'Accept-Ranges': 'bytes' } });
}

async function refreshConfig() {
  try {
    const res = await fetch(`${CONFIG_URL}?t=${Date.now()}`, { signal: AbortSignal.timeout(15000), cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const cfg = normalizeConfig(JSON.parse(await res.text()));
    state.config = cfg; state.configSource = 'live'; state.configError = null;
    writeJson(dataFile('config-cache.json'), cfg);
  } catch (e) {
    state.configError = String(e.message || e);
    if (!state.config) {
      const cached = readJson(dataFile('config-cache.json'), null);
      if (cached) { state.config = cached; state.configSource = 'cache'; }
      else {
        state.config = readJson(path.join(__dirname, '..', 'assets', 'servers.default.json'), { servers: [] });
        state.configSource = 'builtin';
      }
    }
  }
  checkForUpdate();
  push();
  refreshImages();
  refreshJoinMedia();
}

function versionNewer(a, b) {
  const pa = String(a || '').split('.').map(Number); const pb = String(b || '').split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return true; if ((pa[i] || 0) < (pb[i] || 0)) return false; }
  return false;
}
function checkForUpdate() {
  // Fallback only: used when the GitHub release check can't run.
  const l = state.config && state.config.launcher;
  if (l && l.latestVersion && versionNewer(l.latestVersion, app.getVersion())) {
    state.updateAvailable = { version: l.latestVersion, url: l.downloadUrl || RELEASES_PAGE, notes: l.notes || '' };
  } else state.updateAvailable = null;
}

// ---------------- Discord announcements (announcements.json) ----------------
const ANN_REFRESH_MS = 2 * 60 * 1000;
const ANN_REFRESH_LIVE_MS = 60 * 1000; // when an announcementsUrl (Worker) is set
function idGreater(a, b) { try { return BigInt(a) > BigInt(b); } catch { return false; } }

async function fetchAnnouncements() {
  // servers.json "announcementsUrl": the Cloudflare Worker that reads Discord live (fast).
  // The GitHub copy (written by the scheduled GitHub job) stays as a fallback.
  const live = state.config && /^https:\/\/[^\s]+$/.test(String(state.config.announcementsUrl || '')) ? String(state.config.announcementsUrl) : null;
  const tries = [
    ...(live ? [[live, { 'User-Agent': 'OWG-Launcher' }]] : []),
    [`https://api.github.com/repos/XCITEDMAN/OWGLauncher/contents/announcements.json`, { Accept: 'application/vnd.github.raw+json', 'User-Agent': 'OWG-Launcher' }],
    [`https://raw.githubusercontent.com/XCITEDMAN/OWGLauncher/main/announcements.json?t=${Date.now()}`, {}],
  ];
  for (const [url, headers] of tries) {
    try {
      const res = await fetch(url, { headers, cache: 'no-store', signal: AbortSignal.timeout(15000) });
      if (res.status === 404 && url.includes('github')) return { missing: true };
      if (!res.ok) continue;
      const data = JSON.parse(await res.text());
      if (data && Array.isArray(data.items)) return { data };
    } catch { /* try next */ }
  }
  return null;
}

async function refreshAnnouncements() {
  const r = await fetchAnnouncements();
  if (!r) { if (!state.discord) { const c = readJson(dataFile('announcements-cache.json'), null); if (c) state.discord = c; } push(); return; }
  if (r.missing) { state.discord = null; push(); return; }
  const data = r.data;
  const items = data.items.filter((m) => m && /^\d+$/.test(String(m.id))).slice(0, 25);
  state.discord = { channel: data.channel || null, updated: data.updated || null, items };
  writeJson(dataFile('announcements-cache.json'), state.discord);

  const ids = items.map((m) => String(m.id));
  const maxId = ids.reduce((a, b) => (!a || idGreater(b, a) ? b : a), null);
  const st = state.settings;
  let fresh = [];
  if (maxId) {
    if (!st.lastAnnouncementId) st.lastAnnouncementId = maxId; // first run: nothing counts as new
    else {
      fresh = items.filter((m) => idGreater(m.id, st.lastAnnouncementId));
      if (idGreater(maxId, st.lastAnnouncementId)) st.lastAnnouncementId = maxId;
    }
  }
  const unread = new Set((st.unreadAnnouncements || []).filter((id) => ids.includes(id)));
  for (const m of fresh) unread.add(String(m.id));
  st.unreadAnnouncements = [...unread];
  saveSettings();
  if (fresh.length) announce(fresh);
  push();
}

function plainText(t) {
  return String(t || '').replace(/\{\{ts:(\d+):\w\}\}/g, (_, s) => new Date(Number(s) * 1000).toLocaleString())
    .replace(/[*_~`#>]/g, '').replace(/\s+/g, ' ').trim();
}

function announce(fresh) {
  if (!win || win.isDestroyed()) return;
  if (state.settings.sounds !== false && !state.gameRunning) win.webContents.send('alert');
  if (!win.isFocused()) {
    win.flashFrame(true);
    if (Notification.isSupported()) {
      const m = fresh[0];
      const n = new Notification({
        title: fresh.length > 1 ? `${fresh.length} new OWG announcements` : `OWG announcement from ${m.author || 'Discord'}`,
        body: plainText(m.text).slice(0, 180) || 'Open the launcher to read it.',
        silent: true,
      });
      n.on('click', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
      n.show();
    }
  }
}

// ---------------- auto-update (GitHub Releases) ----------------
const REPO = 'XCITEDMAN/OWGLauncher';
const RELEASES_PAGE = `https://github.com/${REPO}/releases/latest`;
const UPDATE_CHECK_MS = 15 * 60 * 1000;
let updateAbort = null;
const inGame = () => Boolean(state.gameRunning || state.launching || (state.play && state.play.active));
const ASSET_RE = /^OWG-Launcher-Setup-[\d.]+\.exe$/i;
let updateFile = null; let updateBusy = false; let installing = false;

// Latest release info. Uses GitHub's API; if that's rate-limited, reads the release page redirect instead.
async function latestRelease() {
  try {
    const res = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, {
      headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'OWG-Launcher' }, signal: AbortSignal.timeout(15000),
    });
    if (res.ok) {
      const rel = await res.json();
      const asset = (rel.assets || []).find((a) => ASSET_RE.test(a.name));
      return { version: String(rel.tag_name || '').replace(/^v/i, ''), notes: String(rel.body || ''), asset: asset || null };
    }
    if (res.status === 404) return null; // no releases yet
  } catch { /* fall through */ }
  const res = await fetch(RELEASES_PAGE, { redirect: 'manual', signal: AbortSignal.timeout(15000) });
  const loc = res.headers.get('location') || '';
  const m = loc.match(/\/releases\/tag\/v?([\d.]+)$/);
  if (!m) return null;
  const version = m[1];
  const name = `OWG-Launcher-Setup-${version}.exe`;
  return { version, notes: '', asset: { name, browser_download_url: `https://github.com/${REPO}/releases/download/v${version}/${name}`, size: 0, digest: '' } };
}

async function checkGithubUpdate() {
  if (updateBusy || (state.update && state.update.status === 'ready')) return;
  if (inGame()) return; // never download while DayZ is starting or running; checked again after it closes
  updateBusy = true;
  updateAbort = new AbortController();
  try {
    const rel = await latestRelease();
    if (!rel) return;
    const version = rel.version;
    if (!versionNewer(version, app.getVersion())) { state.update = null; return; }
    const asset = rel.asset;
    if (!asset || !ASSET_RE.test(asset.name)) return;
    const url = String(asset.browser_download_url || '');
    if (!url.startsWith(`https://github.com/${REPO}/releases/download/`)) return;
    if (inGame()) return;
    const rel_body = rel.notes;
    const notes = String(rel_body || '').trim().slice(0, 300);
    state.update = { version, notes, status: 'downloading', percent: 0 };
    push();

    const dir = path.join(app.getPath('temp'), 'owg-launcher-update');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, asset.name);
    const dl = await fetch(url, { headers: { 'User-Agent': 'OWG-Launcher' }, signal: AbortSignal.any([updateAbort.signal, AbortSignal.timeout(30 * 60 * 1000)]) });
    if (!dl.ok || !dl.body) throw new Error(`download HTTP ${dl.status}`);
    const total = Number(dl.headers.get('content-length')) || asset.size || 0;
    const hash = crypto.createHash('sha256');
    const out = fs.createWriteStream(file);
    let got = 0; let lastPush = 0;
    for await (const chunk of dl.body) {
      const buf = Buffer.from(chunk);
      hash.update(buf); got += buf.length;
      if (!out.write(buf)) await new Promise((r) => out.once('drain', r));
      if (total && Date.now() - lastPush > 500) { state.update.percent = Math.round((got / total) * 100); lastPush = Date.now(); push(); }
    }
    await new Promise((r, j) => out.end((e) => (e ? j(e) : r())));
    if ((asset.size && got !== asset.size) || (total && got !== total)) throw new Error('download incomplete');
    const digest = String(asset.digest || '');
    if (digest.startsWith('sha256:') && digest.slice(7).toLowerCase() !== hash.digest('hex')) throw new Error('checksum mismatch');
    updateFile = file;
    state.update = { version, notes, status: 'ready', percent: 100 };
  } catch (e) {
    if (state.update && state.update.status === 'downloading') state.update = null;
  } finally {
    updateBusy = false;
    updateAbort = null;
    push();
  }
}

function runInstaller(relaunch) {
  if (!updateFile || !fs.existsSync(updateFile) || installing) return false;
  installing = true;
  const args = ['/S'];
  if (relaunch) args.push('/relaunch');
  const child = spawn(updateFile, args, { detached: true, stdio: 'ignore' });
  child.on('error', () => { installing = false; });
  child.unref();
  return true;
}

// ---------------- server status ----------------
const lastModQuery = {};
const ipCache = {};
async function resolveHost(host) {
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) return host;
  try { const r = await dns.lookup(host, { family: 4 }); ipCache[host] = r.address; return r.address; }
  catch (e) { if (ipCache[host]) return ipCache[host]; throw e; }
}

function configMods(s) {
  return (s.configMods || []).map((m) => ({ id: String(m.workshopId || m.id), name: m.name || '', dlc: Boolean(m.dlc) })).filter((m) => m.id && m.id !== 'undefined');
}

async function pollServer(s) {
  const prev = state.servers[s.id] || {};
  try {
    const ip = await resolveHost(s.host);
    const info = await a2s.queryInfo(ip, s.queryPort);
    state.servers[s.id] = { up: true, info, ip, lastSeen: Date.now(), error: null };
    if (s.modsOverride) {
      state.mods[s.id] = configMods(s); state.modSource[s.id] = 'config';
    } else if (!lastModQuery[s.id] || Date.now() - lastModQuery[s.id] > MODLIST_REFRESH_MS || state.modSource[s.id] !== 'live') {
      try {
        const mods = await a2s.queryMods(ip, s.queryPort);
        lastModQuery[s.id] = Date.now();
        state.mods[s.id] = mods; state.modSource[s.id] = 'live';
        const cache = readJson(dataFile('mods-cache.json'), {}); cache[s.id] = mods; writeJson(dataFile('mods-cache.json'), cache);
      } catch { /* keep previous */ }
    }
  } catch (e) {
    state.servers[s.id] = { up: false, info: null, ip: prev.ip || null, lastSeen: prev.lastSeen || null, error: String(e.message || e) };
  }
  if (!state.mods[s.id]) {
    const cache = readJson(dataFile('mods-cache.json'), {});
    if (cache[s.id]) { state.mods[s.id] = cache[s.id]; state.modSource[s.id] = 'cache'; }
    else if (s.configMods) { state.mods[s.id] = configMods(s); state.modSource[s.id] = 'config'; }
  }
}

let polling = false;
async function pollAll() {
  if (polling) return; polling = true;
  try { await Promise.all(serverList().map((s) => pollServer(s))); } finally { polling = false; }
  push();
}

// ---------------- mod status (passive) ----------------
let modTimer = null;
const notifiedReady = {};
async function checkMods() {
  clearTimeout(modTimer);
  let busy = false;
  try {
    const paths = await steamLocal.findPaths();
    state.dayzFound = Boolean(paths.dayzDir);
    state.steamRunning = await steamLocal.isSteamRunning();
    const ids = [...new Set(Object.values(state.mods).flat().filter((m) => !m.dlc).map((m) => m.id))];
    if (ids.length) {
      const before = {}; for (const s of serverList()) before[s.id] = s.modSummary;
      Object.assign(state.modStatus, await steamLocal.modStatus(ids));
      for (const s of serverList()) {
        const sum = s.modSummary;
        if (sum.updating.length) busy = true;
        const was = before[s.id];
        if (was && was.updating.length && !sum.updating.length && sum.ready === sum.total && !notifiedReady[s.id]) {
          notifiedReady[s.id] = true;
          if (Notification.isSupported() && win && !win.isFocused()) new Notification({ title: 'Mods ready', body: `${s.name} is ready to play.` }).show();
        }
        if (sum.updating.length) notifiedReady[s.id] = false;
      }
    }
  } catch { /* ignore */ }
  push();
  modTimer = setTimeout(checkMods, busy || state.play ? MODCHECK_ACTIVE_MS : MODCHECK_IDLE_MS);
}

// ---------------- Steam helper process ----------------
let worker = null; let reqId = 0; const pending = new Map();
function startWorker() {
  if (worker) return worker;
  worker = fork(path.join(__dirname, 'steam-worker.js'), [], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
    stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
    windowsHide: true,
  });
  worker.on('message', (m) => { const p = pending.get(m.id); if (p) { pending.delete(m.id); p(m); } });
  worker.on('exit', () => { worker = null; for (const p of pending.values()) p({ ok: false, error: 'worker-exited' }); pending.clear(); });
  return worker;
}
function call(cmd, args = {}, timeoutMs = 30000) {
  const w = startWorker();
  return new Promise((resolve) => {
    const id = ++reqId;
    const t = setTimeout(() => { pending.delete(id); resolve({ ok: false, error: 'timeout' }); }, timeoutMs);
    pending.set(id, (m) => { clearTimeout(t); resolve(m); });
    w.send({ id, cmd, ...args });
  });
}
async function stopWorker() {
  if (!worker) return;
  const w = worker;
  await call('quit', {}, 3000);
  await new Promise((r) => setTimeout(r, 300));
  try { w.kill(); } catch {}
  worker = null;
}

// ---------------- server passwords ----------------
// Remembered passwords are encrypted with Windows' per-user protection (DPAPI).
const sessionPasswords = {};
function getPassword(id) {
  if (sessionPasswords[id]) return sessionPasswords[id];
  const enc = state.settings.passwords && state.settings.passwords[id];
  if (!enc) return null;
  try {
    if (enc.startsWith('enc:') && safeStorage.isEncryptionAvailable()) return safeStorage.decryptString(Buffer.from(enc.slice(4), 'base64'));
    if (enc.startsWith('b64:')) return Buffer.from(enc.slice(4), 'base64').toString('utf8');
  } catch {}
  return null;
}
function setPassword(id, pw, remember) {
  state.settings.passwords = { ...(state.settings.passwords || {}) };
  delete sessionPasswords[id];
  delete state.settings.passwords[id];
  if (pw) {
    if (remember) {
      state.settings.passwords[id] = safeStorage.isEncryptionAvailable()
        ? `enc:${safeStorage.encryptString(pw).toString('base64')}`
        : `b64:${Buffer.from(pw, 'utf8').toString('base64')}`;
    } else sessionPasswords[id] = pw;
  }
  saveSettings();
}
const cleanPw = (pw) => String(pw || '').replace(/["\r\n]/g, '').slice(0, 64);

// ---------------- play flow ----------------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function setPlay(p) { state.play = p ? { ...(state.play || {}), ...p } : null; push(); }
function fmtMB(n) { return `${Math.round((n || 0) / 1048576)} MB`; }

async function play(serverId, opts = {}) {
  if (opts && typeof opts.password === 'string' && opts.password) setPassword(serverId, cleanPw(opts.password), opts.remember !== false);
  if (state.play && state.play.active) return;
  if (state.gameRunning || state.launching) return; // one DayZ at a time
  if (updateAbort) updateAbort.abort(); // joining takes priority over a launcher update download
  const s = serverList().find((x) => x.id === serverId);
  if (!s) return;
  const token = Date.now() + Math.random();
  setPlay({ active: true, serverId, token, phase: 'prepare', message: 'Checking Steam…', items: [], error: null, stuck: false, storeAppIds: null, percent: null });
  const cancelled = () => !state.play || state.play.token !== token;
  const fail = async (message, extra = {}) => { await stopWorker(); setPlay({ active: false, phase: 'error', error: message, ...extra }); };

  try {
    if (!(await steamLocal.isSteamRunning())) return fail('Steam isn’t running. Start Steam, sign in, then click Play again.');
    const paths = await steamLocal.findPaths(true);

    const init = await call('init', {}, 20000);
    if (!init.ok) return fail('Couldn’t connect to Steam. Make sure Steam is open and signed in to the account that owns DayZ.');
    const dayzDir = (init.dayzDir && fs.existsSync(init.dayzDir)) ? init.dayzDir : paths.dayzDir;
    if (!dayzDir) return fail('DayZ doesn’t seem to be installed on this PC.');
    if (!state.settings.playerName && init.name) { state.settings.playerName = init.name; saveSettings(); }

    // Freshest possible mod list.
    setPlay({ message: 'Getting the server’s mod list…' });
    await pollServer(serverList().find((x) => x.id === serverId) || s);
    const srv = serverList().find((x) => x.id === serverId) || s;
    if (!srv.status || !srv.status.up) return fail(`${srv.name} isn’t responding right now. It may be down or restarting.`);
    if (srv.status.info && srv.status.info.passworded && !getPassword(srv.id)) {
      await stopWorker();
      return setPlay({ active: false, phase: 'password', message: null, items: [] });
    }
    const mods = srv.mods || [];
    const dlcs = mods.filter((m) => m.dlc);
    const wsMods = mods.filter((m) => !m.dlc);

    if (dlcs.length) {
      const r = await call('dlc', { appIds: dlcs.map((d) => d.id) });
      const missing = dlcs.filter((d) => r.ok && r.dlc && r.dlc[d.id] === false);
      if (missing.length) {
        return fail(`${srv.name} requires DayZ DLC you don’t own (Steam app ${missing.map((m) => m.id).join(', ')}).`, { storeAppIds: missing.map((m) => m.id) });
      }
    }

    // Subscribe + download, then wait until Steam says everything is in place.
    const ids = wsMods.map((m) => m.id);
    let folders = {}; let hadToDownload = false;
    if (ids.length) {
      setPlay({ phase: 'mods', message: 'Checking your mods…' });
      await call('ensure', { ids }, 120000);
      let lastProgress = Date.now(); let lastBytes = -1; let lastKick = Date.now();
      for (;;) {
        if (cancelled()) { await stopWorker(); return; }
        const r = await call('status', { ids });
        if (!r.ok) return fail('Lost contact with Steam while checking mods. Make sure Steam is still running.');
        const items = ids.map((id) => {
          const it = r.items[id]; const m = wsMods.find((x) => x.id === id);
          return { ...it, name: m.name || (state.modStatus[id] && state.modStatus[id].title) || id };
        });
        const notReady = items.filter((i) => !i.ready);
        if (notReady.length) hadToDownload = true;
        const bytes = items.reduce((a, i) => a + (i.current || 0), 0);
        if (bytes !== lastBytes) { lastBytes = bytes; lastProgress = Date.now(); }
        const stuck = notReady.length > 0 && Date.now() - lastProgress > 60000;
        if (notReady.length && Date.now() - lastKick > 20000) { lastKick = Date.now(); await call('ensure', { ids: notReady.map((i) => i.id) }); }
        const total = notReady.reduce((a, i) => a + (i.total || 0), 0);
        const done = notReady.reduce((a, i) => a + (i.current || 0), 0);
        setPlay({
          items: notReady.map((i) => ({ id: i.id, name: i.name, current: i.current, total: i.total, downloading: i.downloading, pending: i.pending || (!i.downloading && !i.installed) })),
          message: notReady.length ? `Steam is downloading ${notReady.length} mod${notReady.length > 1 ? 's' : ''} for ${srv.name}${total ? ` — ${fmtMB(done)} of ${fmtMB(total)}` : '…'}` : 'Mods ready.',
          percent: total ? Math.min(100, Math.round((done / total) * 100)) : null,
          stuck,
        });
        if (!notReady.length) { folders = Object.fromEntries(items.map((i) => [i.id, i.folder])); break; }
        await sleep(1000);
      }
    }

    if (!state.settings.autoJoin && hadToDownload) {
      // Auto-join off: stop once mods are ready; the player clicks Play again.
      await stopWorker();
      setPlay({ active: false, phase: 'ready', message: `Mods ready. Click Play to join ${srv.name}.` });
      return;
    }
    if (cancelled()) { await stopWorker(); return; }

    // Link mods into the DayZ folder with short names: !OWG\@<id>
    setPlay({ phase: 'launch', message: `Launching DayZ and joining ${srv.name}…`, items: [], percent: null });
    const modArg = linkMods(dayzDir, ids, folders);
    await stopWorker();

    const ip = srv.status.ip;
    state.launching = { serverId: srv.id, at: Date.now() };
    watchGame(true);
    launchDayz(paths, dayzDir, ip, srv.gamePort, modArg, srv.status.info && srv.status.info.passworded ? getPassword(srv.id) : null);
    state.settings.lastServerId = srv.id; saveSettings();
    setPlay({ active: false, phase: 'launched', message: `DayZ is starting — joining ${srv.name}.` });
    setTimeout(() => { if (state.play && state.play.phase === 'launched') setPlay(null); if (win && state.settings.minimizeOnLaunch) win.minimize(); }, 4000);
  } catch (e) {
    await fail(`Something went wrong: ${e.message || e}`);
  }
}

function linkMods(dayzDir, ids, folders) {
  if (!ids.length) return '';
  const base = path.join(dayzDir, '!OWG');
  fs.mkdirSync(base, { recursive: true });
  const names = [];
  for (const id of ids) {
    const target = folders[id];
    if (!target) continue;
    const link = path.join(base, `@${id}`);
    let current = null;
    try { current = fs.readlinkSync(link); } catch {}
    if (current && path.resolve(current) !== path.resolve(target)) {
      try { fs.unlinkSync(link); } catch { try { fs.rmdirSync(link); } catch {} }
      current = null;
    }
    if (!current && !fs.existsSync(link)) fs.symlinkSync(target, link, 'junction');
    names.push(`!OWG\\@${id}`);
  }
  return names.join(';');
}

function launchDayz(paths, dayzDir, ip, port, modArg, password) {
  const gameArgs = ['-nolauncher', '-world=empty', `-connect=${ip}`, `-port=${port}`];
  if (modArg) gameArgs.push(`-mod=${modArg}`);
  if (state.settings.playerName) gameArgs.push(`-name=${state.settings.playerName}`);
  if (password) gameArgs.push(`-password=${password}`);
  if (state.settings.extraParams) gameArgs.push(...String(state.settings.extraParams).split(/\s+/).filter(Boolean));
  // Start through DayZ_BE.exe so BattlEye runs; servers with BattlEye kick
  // clients that were started without it ("Game restart required").
  const beExe = path.join(dayzDir, 'DayZ_BE.exe');
  const viaSteam = () => {
    if (!paths.steamExe) return;
    const c = spawn(paths.steamExe, ['-applaunch', steamLocal.DAYZ_APP, ...gameArgs], { detached: true, stdio: 'ignore' });
    c.on('error', () => {});
    c.unref();
  };
  if (!fs.existsSync(beExe)) return viaSteam();
  const child = spawn(beExe, ['-exe', 'DayZ_x64.exe', ...gameArgs], { cwd: dayzDir, detached: true, stdio: 'ignore', windowsHide: false });
  child.on('error', () => viaSteam());
  child.unref();
}

// ---------------- is DayZ running? ----------------
// Checks every 3 s while DayZ is starting or open (so Play unlocks soon after it closes),
// and every 15 s otherwise.
const LAUNCH_TIMEOUT_MS = 3 * 60 * 1000;
let gameTimer = null;
let wasBusy = false;
async function watchGame(now = false) {
  clearTimeout(gameTimer);
  if (!now) {
    const running = await steamLocal.isDayzRunning();
    let changed = running !== state.gameRunning;
    state.gameRunning = running;
    if (running && state.launching) { state.launching = null; changed = true; }
    if (!running && state.launching && Date.now() - state.launching.at > LAUNCH_TIMEOUT_MS) {
      state.launching = null; changed = true; // DayZ never appeared: unlock so the player can try again
    }
    if (changed) push();
    if ((running || state.launching) && updateAbort) updateAbort.abort(); // game started: stop any update download
    if (wasBusy && !inGame()) setTimeout(checkGithubUpdate, 10000); // game closed: catch up on updates
    wasBusy = inGame();
  }
  gameTimer = setTimeout(() => watchGame(false), state.launching || state.gameRunning ? 3000 : 15000);
}

// ---------------- settings ----------------
function saveSettings() { writeJson(dataFile('settings.json'), state.settings); }

// ---------------- window + IPC ----------------
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 760, minWidth: 980, minHeight: 640,
    frame: false, backgroundColor: '#0c1117', show: false,
    icon: path.join(__dirname, '..', 'assets', 'icon.png'),
    title: 'OWG Launcher',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.on('focus', () => win.flashFrame(false));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

app.whenReady().then(async () => {
  protocol.handle('owg-img', (req) => {
    const u = new URL(req.url);
    const name = decodeURIComponent(u.pathname.replace(/^\//, ''));
    if (u.host === 'media') {
      const hit = Object.values(mediaCache).find((c) => path.basename(c.file) === name);
      return hit ? serveFile(hit.file, req) : new Response('', { status: 404 });
    }
    const img = serverImages[name];
    if (!img || !fs.existsSync(img.file)) return new Response('', { status: 404 });
    return serveFile(img.file, req);
  });
  Object.assign(mediaCache, readJson(mediaIndexFile(), {}));
  // Show cached artwork immediately, before the first download check.
  Object.assign(serverImages, Object.fromEntries(Object.entries(readJson(imgIndexFile(), {})).filter(([, v]) => v && v.file && fs.existsSync(v.file))));
  state.settings = { ...state.settings, ...readJson(dataFile('settings.json'), {}) };
  createWindow();

  ipcMain.handle('get-state', () => publicState());
  ipcMain.handle('mark-read', (_e, id) => {
    const st = state.settings;
    st.unreadAnnouncements = id === 'all' ? [] : (st.unreadAnnouncements || []).filter((x) => x !== String(id));
    saveSettings(); push(); return true;
  });
  ipcMain.handle('install-update', async () => {
    if (!state.update || state.update.status !== 'ready') return false;
    if (state.play && state.play.active) return false;
    state.update = { ...state.update, status: 'installing' }; push();
    await stopWorker();
    if (runInstaller(true)) setTimeout(() => app.exit(0), 600);
    return true;
  });
  ipcMain.handle('play', (_e, id, opts) => { play(id, opts || {}); return true; });
  ipcMain.handle('set-password', (_e, id, pw, remember) => { setPassword(String(id), cleanPw(pw), remember !== false); push(); return true; });
  ipcMain.handle('cancel', async () => { await stopWorker(); setPlay(null); return true; });
  ipcMain.handle('dismiss', () => { if (state.play && !state.play.active) setPlay(null); return true; });
  ipcMain.handle('refresh', async () => { await refreshConfig(); refreshAnnouncements(); checkGithubUpdate(); await pollAll(); checkMods(); return true; });
  ipcMain.handle('save-settings', (_e, s) => {
    const allowed = {};
    if (typeof s.playerName === 'string') allowed.playerName = s.playerName.replace(/["\r\n]/g, '').slice(0, 32);
    if (typeof s.autoJoin === 'boolean') allowed.autoJoin = s.autoJoin;
    if (typeof s.minimizeOnLaunch === 'boolean') allowed.minimizeOnLaunch = s.minimizeOnLaunch;
    if (typeof s.sounds === 'boolean') allowed.sounds = s.sounds;
    if (typeof s.extraParams === 'string') allowed.extraParams = s.extraParams.replace(/["\r\n]/g, '').slice(0, 200);
    state.settings = { ...state.settings, ...allowed }; saveSettings(); push(); return true;
  });
  ipcMain.handle('open-url', (_e, url) => {
    if (/^https:\/\/[^\s]+$/.test(String(url)) || /^steam:\/\/(store|url\/CommunityFilePage)\/\d+$/.test(url)) shell.openExternal(url);
    return true;
  });
  ipcMain.handle('win', (_e, action) => {
    if (!win) return;
    if (action === 'min') win.minimize();
    else if (action === 'max') win.isMaximized() ? win.unmaximize() : win.maximize();
    else if (action === 'close') win.close();
  });

  await refreshConfig();
  pollAll();
  checkMods();
  watchGame();
  setInterval(refreshConfig, CONFIG_REFRESH_MS);
  // Announcements: every minute with a live Worker URL, every 2 minutes from GitHub.
  const annLoop = async () => {
    await refreshAnnouncements();
    setTimeout(annLoop, state.config && state.config.announcementsUrl ? ANN_REFRESH_LIVE_MS : ANN_REFRESH_MS);
  };
  annLoop();
  setInterval(pollAll, STATUS_REFRESH_MS);
  setTimeout(checkGithubUpdate, 5000);
  setInterval(checkGithubUpdate, UPDATE_CHECK_MS);
});

app.on('window-all-closed', async () => {
  await stopWorker();
  // An update that finished downloading installs quietly when the launcher closes.
  if (state.update && state.update.status === 'ready' && !state.gameRunning) runInstaller(false);
  app.quit();
});
