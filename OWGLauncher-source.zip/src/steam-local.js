// Reads Steam's own files to find DayZ, its Workshop mods, and what Steam is
// currently downloading — without starting the Steam API (so the player does
// not show up as "playing DayZ" just because the launcher is open).
'use strict';
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const DAYZ_APP = '221100';

// --- tiny VDF (Valve KeyValues text) parser ---
function parseVdf(text) {
  const root = {};
  const stack = [root];
  const re = /"((?:\\.|[^"\\])*)"|([{}])/g;
  let m;
  let pendingKey = null;
  while ((m = re.exec(text))) {
    const cur = stack[stack.length - 1];
    if (m[2] === '{') {
      const obj = {};
      if (pendingKey !== null) cur[pendingKey.toLowerCase()] = obj;
      stack.push(obj);
      pendingKey = null;
    } else if (m[2] === '}') {
      stack.pop();
      pendingKey = null;
    } else {
      const s = m[1].replace(/\\\\/g, '\\').replace(/\\"/g, '"');
      if (pendingKey === null) pendingKey = s;
      else { cur[pendingKey.toLowerCase()] = s; pendingKey = null; }
    }
  }
  return root;
}

function readVdf(file) {
  try { return parseVdf(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function regQuery(key, value) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(null);
    execFile('reg', ['query', key, '/v', value], { windowsHide: true }, (err, out) => {
      if (err) return resolve(null);
      const line = out.split(/\r?\n/).find((l) => l.includes(value));
      if (!line) return resolve(null);
      const parts = line.trim().split(/\s{2,}|\t/);
      resolve(parts[parts.length - 1] || null);
    });
  });
}

let cachedPaths = null;

async function findPaths(force = false) {
  if (cachedPaths && !force) return cachedPaths;
  let steamRoot = await regQuery('HKCU\\Software\\Valve\\Steam', 'SteamPath');
  if (!steamRoot) steamRoot = await regQuery('HKLM\\SOFTWARE\\WOW6432Node\\Valve\\Steam', 'InstallPath');
  if (!steamRoot) steamRoot = 'C:\\Program Files (x86)\\Steam';
  steamRoot = path.normalize(steamRoot);
  const steamExe = path.join(steamRoot, 'steam.exe');

  // Find the library folder DayZ lives in.
  let library = steamRoot;
  const lf = readVdf(path.join(steamRoot, 'steamapps', 'libraryfolders.vdf'));
  if (lf && lf.libraryfolders) {
    for (const entry of Object.values(lf.libraryfolders)) {
      if (entry && typeof entry === 'object' && entry.apps && entry.apps[DAYZ_APP] !== undefined && entry.path) {
        library = path.normalize(entry.path);
        break;
      }
    }
  }
  const steamapps = path.join(library, 'steamapps');
  let dayzDir = null;
  const manifest = readVdf(path.join(steamapps, `appmanifest_${DAYZ_APP}.acf`));
  if (manifest && manifest.appstate && manifest.appstate.installdir) {
    dayzDir = path.join(steamapps, 'common', manifest.appstate.installdir);
  } else if (fs.existsSync(path.join(steamapps, 'common', 'DayZ'))) {
    dayzDir = path.join(steamapps, 'common', 'DayZ');
  }
  cachedPaths = {
    steamRoot,
    steamExe: fs.existsSync(steamExe) ? steamExe : null,
    steamapps,
    dayzDir: dayzDir && fs.existsSync(dayzDir) ? dayzDir : null,
    workshopContent: path.join(steamapps, 'workshop', 'content', DAYZ_APP),
    workshopDownloads: path.join(steamapps, 'workshop', 'downloads', DAYZ_APP),
    workshopAcf: path.join(steamapps, 'workshop', `appworkshop_${DAYZ_APP}.acf`),
  };
  return cachedPaths;
}

function dirSize(dir) {
  let total = 0;
  const walk = (d) => {
    let entries;
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else { try { total += fs.statSync(p).size; } catch {} }
    }
  };
  walk(dir);
  return total;
}

function isSteamRunning() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(false);
    execFile('tasklist', ['/FI', 'IMAGENAME eq steam.exe', '/NH'], { windowsHide: true }, (err, out) => {
      resolve(!err && /steam\.exe/i.test(out));
    });
  });
}

function isDayzRunning() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(false);
    execFile('tasklist', ['/FI', 'IMAGENAME eq DayZ_x64.exe', '/NH'], { windowsHide: true }, (err, out) => {
      resolve(!err && /DayZ_x64\.exe/i.test(out));
    });
  });
}

// Latest info for Workshop items from Steam's public web API (no key needed).
const webCache = new Map(); // id -> {at, data}
async function workshopDetails(ids) {
  const now = Date.now();
  const need = ids.filter((id) => { const c = webCache.get(id); return !c || now - c.at > 5 * 60 * 1000; });
  if (need.length) {
    const body = new URLSearchParams();
    body.set('itemcount', String(need.length));
    need.forEach((id, i) => body.set(`publishedfileids[${i}]`, id));
    try {
      const res = await fetch('https://api.steampowered.com/ISteamRemoteStorage/GetPublishedFileDetails/v1/', {
        method: 'POST', body, signal: AbortSignal.timeout(10000),
      });
      const json = await res.json();
      for (const d of (json.response && json.response.publishedfiledetails) || []) {
        if (d.result === 1) {
          webCache.set(String(d.publishedfileid), {
            at: now,
            data: { title: d.title, size: Number(d.file_size || 0), timeUpdated: Number(d.time_updated || 0) },
          });
        }
      }
    } catch { /* offline: fall back to what Steam's files say */ }
  }
  const out = {};
  for (const id of ids) { const c = webCache.get(id); if (c) out[id] = c.data; }
  return out;
}

// Passive status of each mod, from Steam's files + the web API.
async function modStatus(modIds) {
  const p = await findPaths();
  const acf = readVdf(p.workshopAcf);
  const ws = (acf && acf.appworkshop) || {};
  const installed = ws.workshopitemsinstalled || {};
  const details = ws.workshopitemdetails || {};
  const web = await workshopDetails(modIds);
  const result = {};
  for (const id of modIds) {
    const inst = installed[id];
    const det = details[id] || {};
    const folder = path.join(p.workshopContent, id);
    const hasFolder = fs.existsSync(folder);
    const dlDir = path.join(p.workshopDownloads, id);
    const downloading = fs.existsSync(dlDir);
    const w = web[id];
    let needsUpdate = false;
    if (det.latest_manifest && det.manifest && det.latest_manifest !== det.manifest) needsUpdate = true;
    if (w && inst && Number(inst.timeupdated || 0) && w.timeUpdated > Number(inst.timeupdated)) needsUpdate = true;
    const st = {
      id,
      title: w ? w.title : null,
      installed: Boolean(inst) && hasFolder,
      subscribed: Boolean(det.subscribedby) || Boolean(inst),
      needsUpdate,
      downloading,
      current: 0,
      total: w ? w.size : 0,
      folder: hasFolder ? folder : null,
    };
    if (downloading) st.current = Math.min(dirSize(dlDir), st.total || Infinity);
    st.ready = st.installed && !st.needsUpdate && !st.downloading;
    result[id] = st;
  }
  return result;
}

module.exports = { parseVdf, findPaths, modStatus, workshopDetails, isSteamRunning, isDayzRunning, DAYZ_APP };
